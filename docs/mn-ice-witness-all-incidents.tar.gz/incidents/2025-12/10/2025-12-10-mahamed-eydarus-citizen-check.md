---
date: 2025-12-10
time: morning
location: Fridley
city: Fridley
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-15T20:00:44
last_updated: 2026-02-08T15:36:25
search_tags: us-citizen, citizen-check, family-separation, src:nbc, src:sahan-journal, src:star-tribune, src:other-local
---

# U.S. Citizen Questioned for Speaking Somali While Shoveling Snow with Mother

## Summary
Mahamed Eydarus, a 25-year-old U.S. citizen of Somali descent from Fridley, was detained by masked ICE agents on the morning of December 10, 2025, while shoveling snow with his mother after finishing an overnight shift as a personal care assistant. Agents surrounded him in unmarked vehicles, asked why he and his mother were speaking a "foreign language," demanded his mother remove her niqab (religious face covering), and separated him from his mother before eventually releasing them. Eydarus is now a plaintiff in the ACLU class-action lawsuit against ICE.

## Sources
1. MN Daily (Dec 13, 2025): [As ICE agents flood the Twin Cities, immigrants and citizens alike are caught in the crossfire](https://mndaily.com/city/as-ice-agents-flood-the-twin-cities-immigrants-and-citizens-alike-are-caught-in-the-crossfire/12/13/2025/)
2. NBC News (Jan 15, 2026): [Lawsuit accuses federal agents of racial profiling in Minneapolis immigration operation](https://www.nbcnews.com/news/us-news/lawsuit-accuses-federal-agents-racial-profiling-minneapolis-immigratio-rcna254245)
3. Sahan Journal (Jan 15, 2026): [ACLU lawsuit: ICE violates constitutional rights in Minnesota](https://sahanjournal.com/immigration/aclu-federal-lawsuit-ice-minnesota/)
4. Star Tribune (Jan 15, 2026): [ACLU sues feds over alleged racial profiling in Twin Cities immigration surge](https://www.startribune.com/aclu-sues-feds-over-alleged-racial-profiling-in-twin-cities-immigration-surge/601564707)

## Affected Individual(s)
- **Name:** Mahamed Eydarus
- **Age:** 25
- **Residence:** Fridley, MN
- **Occupation:** Personal care assistant (had just finished overnight shift)
- **Citizenship:** U.S. Citizen
- **Ethnicity:** Somali descent
- **Mother:** Also U.S. citizen, also detained briefly

## Timeline
- **Morning, December 10, 2025** - Eydarus finishes overnight shift as personal care assistant.
- **Shortly after** - Eydarus and mother begin shoveling snow from his parking space.
- **During shoveling** - Masked agents in unmarked vehicles surround him.
- **Detention begins** - Agents ask why they are speaking a "foreign language."
- **Religious violation** - Agents demand mother remove her niqab (religious face covering).
- **Separation** - Eydarus separated from his mother
- **Lengthy detention** - Both held "for a lengthy period"
- **Release** - Both released after showing identification

## What Happened
According to the ACLU lawsuit filed January 15, 2026:

1. Eydarus was shoveling snow with his mother when masked federal agents pulled up in unmarked vehicles
2. When he looked up from shoveling, agents had already surrounded him
3. They approached and asked him to present identification
4. Agents refused to identify themselves
5. Agents asked why Eydarus and his mother were speaking a "foreign language"
6. Agents ordered his mother to remove her niqab (a religious and cultural face covering)
7. Agents separated Eydarus from his mother
8. Both were detained "for a lengthy period" before being released after showing ID

### Right-Wing Influencer Filming
Adding to Eydarus's fears was a man with the agents using a phone on an extended mount to film him. Per the Minnesota Daily, this man was Ben Bergquam, an influencer from right-wing television network Real America's Voice. Eydarus said he was uncomfortable providing identification while being filmed by someone who was clearly not law enforcement. "It felt like a reality show," he said. Bergquam's role in the operations is unclear, and neither Bergquam nor Real America's Voice responded to the Minnesota Daily's request for comment.

## Constitutional Violations Alleged
- **Fourth Amendment:** Unreasonable seizure without probable cause
- **First Amendment:** Religious expression (demanding removal of niqab)
- **Equal Protection:** Racial profiling based on ethnicity and language

## Impact on Affected Individual
Per the lawsuit: "Mr. Eydarus is scared to go about his daily life in public, as he fears being again detained based on his Somali descent and appearance."

## Official Accounts

### DHS Response
A DHS spokesperson called the allegations "disgusting, reckless, and categorically FALSE," stating: "What makes someone a target for immigration enforcement is if they are illegally in the U.S.—NOT their skin color, race, or ethnicity."

## Legal Action
Eydarus is one of three plaintiffs in ACLU of Minnesota's class-action lawsuit filed January 15, 2026:
- **Case:** Filed in federal court
- **Defendants:** DHS Secretary Kristi Noem, ICE Director Todd Lyons
- **Relief sought:** Statewide injunction against racial profiling practices

## Context
This incident occurred on the same day as the Mubashir Khalif Hussen wrongful detention in Cedar-Riverside. Both cases involve U.S. citizens of Somali descent being detained despite repeatedly asserting their citizenship, demonstrating a pattern of racial profiling.
