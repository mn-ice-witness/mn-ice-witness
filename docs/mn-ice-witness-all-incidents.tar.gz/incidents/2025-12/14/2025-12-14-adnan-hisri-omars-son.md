---
date: 2025-12-13
time: unknown
location: Near Target store
city: Minneapolis
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-14T09:04:50
last_updated: 2026-01-14T09:04:50
search_tags: us-citizen, citizen-check, src:nbc, src:wcco, src:fox-news, src:bring-me-the-news, src:star-tribune, src:other-national
---

# U.S. Citizen Son of Rep. Ilhan Omar Stopped by ICE, Released After Showing Passport

## Summary
Adnan Hirsi, the 20-year-old U.S.-born son of Rep. Ilhan Omar, was stopped by federal agents after leaving a Target store in Minneapolis. He was released after showing his passport. Rep. Omar said her son "always carries" his passport due to fears of racial profiling. DHS denied any record of the stop.

## Sources
1. NBC News (Dec 15, 2025): [Rep. Ilhan Omar says her son was pulled over by ICE agents in Minnesota](https://www.nbcnews.com/politics/congress/ilhan-omar-son-pulled-over-ice-agents-minnesota-trump-administration-rcna249183)
2. CBS Minnesota (Dec 15, 2025): [Minnesota Rep. Ilhan Omar says her son was pulled over by ICE, which claims "zero record" of the incident](https://www.cbsnews.com/minnesota/news/minnesota-rep-ilhan-omar-says-son-pulled-over-by-ice/)
3. UPI (Dec 15, 2025): [Ilhan Omar says son stopped in Minnesota by ICE during Trump crackdown](https://www.upi.com/Top_News/US/2025/12/15/Minnesota-Ilhan-Omar-son-ICE/2381765833444/)
4. Fox News (Dec 15, 2025): [Omar's son stopped by ICE agents in Minnesota, released after showing passport](https://www.foxnews.com/politics/ilhan-omar-claims-ice-pulled-son-racial-profiling-sweep-trumps-crackdown-minnesota)
5. BET News (Dec 15, 2025): ["They Are Racially Profiling": Ilhan Omar says ICE stopped her son](https://www.bet.com/article/6qxy0k/they-are-racially-profiling-ilhan-omar-says-ice-stopped-her-son-in-minneapolis)
6. The Hill (Dec 15, 2025): [Ilhan Omar says son targeted by ICE in traffic stop](https://thehill.com/homenews/state-watch/5649719-ice-targeting-somalians-minnesota/)
7. The Hill (Dec 16, 2025): [DHS denies claims of ICE profiling Rep. Ilhan Omar's son](https://thehill.com/policy/national-security/5651778-omar-son-ice-incident-dispute/)
8. Bring Me The News (Dec 15, 2025): [Recent ICE activity - Ilhan Omar's son stopped](https://bringmethenews.com/minnesota-news/recent-ice-activity-chanhassen-rooftop-standoff-ilhan-omars-son-stopped)
9. X Post (Dec 15, 2025): [@Combs0294 on racial profiling](https://x.com/Combs0294/status/2001107480474960204)
10. Star Tribune (Jan 18, 2026): [Allegations of racial profiling of U.S. citizens on the rise as ICE surge expands in Minnesota](https://www.startribune.com/allegations-of-racial-profiling-of-us-citizens-on-the-rise-as-ice-surge-expands-in-minnesota/601564653)

## Affected Individual(s)
- **Name:** Adnan Hirsi
- **Age:** 20
- **Citizenship:** U.S. Citizen (born in United States)
- **Relationship:** Son of Rep. Ilhan Omar (D-MN)

## What Happened
According to Rep. Omar, her son was stopped by ICE agents on Saturday, December 13, 2025, after leaving a Target store. He was asked to prove his citizenship. After producing his passport, he was released.

## Rep. Omar's Statements
- "Yesterday after he made a stop at Target, he did get pulled over by ICE agents and once he was able to produce his passport ID they did let him go."
- "I had to remind him just how worried I am because all of these areas they're talking about are areas where he can possibly find himself in and they are racially profiling."
- "They are looking for young men who look Somali, that they think are undocumented."
- Omar noted her son "always carries" his passport over fears of ICE encounters
- Omar said her son has had previous encounters with federal agents, including at a Twin Cities mosque where agents entered while he and others were praying

## DHS Response
- "ICE has absolutely ZERO record of its officers or agents pulling over Congresswoman Omar's son."
- Accused Omar of making "unsupported accusations."
- Called claims of racial profiling "disgusting, reckless and categorically FALSE."
- Said ICE enforcement actions are based on "reasonable suspicion" under the Fourth Amendment.

## Rep. Omar's Office Response
"The congresswoman's son and others were pulled over by ICE, racially profiled, and forced to prove their citizenship with a passport. ICE has long operated as a rogue agency beyond reform. It's no surprise that an agency known for disappearing people also can't keep its records straight."

## Significance
This incident highlights concerns about:
- Racial profiling of Somali-Americans and other people of color
- U.S. citizens being forced to carry passports to prove citizenship
- Disputed record-keeping by federal agencies
- Minnesota being home to the largest Somali community in the U.S.
