---
date: 2025-12-04
time: unknown
location: DHS Press Release
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-14T13:25:50
last_updated: 2026-01-14T13:25:50
search_tags: legal-resident
---

# DHS Response: Abdulkadir Abdi "Gang Member"

## Summary
In the first Operation Metro Surge press release, DHS labeled Abdulkadir Sharif Abdi as a current gang member. This characterization differs from a 2018 federal court finding that he had "turned his life around" and his family's statements that he is not currently in a gang.

## Sources
1. DHS (Dec 4, 2025): [DHS Press Release - Operation Metro Surge Arrests](https://www.dhs.gov/news/2025/12/04/ice-arrests-worst-worst-criminal-illegal-aliens-during-operation-metro-surge)

## Related Incident
See full incident details: [Addiction Recovery Leader Detained, Labeled "Gang Member"](#2025-12-04-abdulkadir-abdi-detained)

## Official Statement

### DHS Press Release (December 4, 2025)
DHS listed Abdulkadir Sharif Abdi first among 12 individuals arrested during Operation Metro Surge, describing him as:

> "...was a former member of the Gangster Disciples and is a known current member of Vice Lord Nation" with convictions for fraud, receiving stolen property, receiving a stolen vehicle, vehicle theft, and multiple probation violations.

### Assistant Secretary Tricia McLaughlin
> "Sanctuary policies and politicians like Tim Walz and Minneapolis Mayor Jacob Frey allowed these pedophiles, domestic terrorists, and gang members to roam the streets and terrorize Americans."

> "ICE law enforcement are risking their lives to protect Minnesotans while their own elected officials sit by and do nothing. No matter when and where, ICE will find, arrest, and deport ALL criminal illegal aliens."

## Fact Check

### Claim: Abdi is a "known current member" of Vice Lord Nation

**Court Record (2018):** U.S. Magistrate Sarah B. Mazzie found that Abdi had "worked to turn his life around" since about 2007 and "has worked with law enforcement and the community to discourage young Somali-Americans from associating with gangs and extremist groups."

**Family Response:** His wife Christenson stated Abdi is NOT a current gang member and had turned his life around after getting sober 13 years ago.

**Work History:** Since 2014, Abdi worked at Park Avenue Center substance abuse facility. At time of arrest, he worked at a homeless shelter helping the Indigenous population and held a leadership position in Alcoholics Anonymous.

### Additional Context from Other Sources

- Abdi came to the U.S. in 1996 as a Somali refugee fleeing civil war.
- His criminal activity was in the past; he began rehabilitation around 2007.
- A federal judge released him on his own recognizance in 2019 after the community rallied.
- He has been sober for 13 years and helps others with addiction recovery.
