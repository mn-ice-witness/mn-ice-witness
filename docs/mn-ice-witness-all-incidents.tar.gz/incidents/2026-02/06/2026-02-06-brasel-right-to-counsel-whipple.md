---
date: 2026-02-06
time: unknown
location: Bishop Henry Whipple Federal Building
city: Minneapolis
type: background
status: ongoing
affected_individual_citizenship: various
injuries: none
created: 2026-02-07T14:24:24
last_updated: 2026-02-13T13:43:32
search_tags: src:ap, src:kstp, src:wcco, src:fox9, src:abc, src:star-tribune, src:mn-reformer, src:nyt, src:nbc, src:cnn, src:npr, src:bring-me-the-news, src:sahan-journal, src:other-national, src:other-local, src:mpr, src:cbs
---

# Minnesota's Legal System Buckles Under Weight of Operation Metro Surge

## Updates
- **Feb 13** - Star Tribune [reports](https://www.startribune.com/court-ruling-means-minnesota-immigrants-sent-to-texas-may-have-little-chance-of-returning/601580036) that the Fifth Circuit's Feb 6 mandatory detention ruling means Minnesota immigrants sent to Texas won't be released on bond. Attorneys David Wilson and a nationwide group are requesting a rehearing before the full Fifth Circuit. Immigration attorneys have now filed more than 840 habeas corpus petitions in Minnesota in 2026. Flight trackers estimate 3,000 immigrants have been sent out of state since Jan 1.
- **Feb 12** - Judge Brasel [issued a 41-page emergency restraining order](https://www.startribune.com/judge-rules-whipple-detainees-must-have-access-to-attorneys-private-calls/601581387) requiring DHS to provide detainees with free, private, unmonitored phone access within one hour of arrival, attorney visitation seven days per week in private rooms, written notice of legal services in five languages, and a 72-hour moratorium on out-of-state transfers. The order is temporary, effective until Feb 26.
- **Feb 9** - Attorneys Kim Boche and Hanne Sandison of the Advocates for Human Rights [conducted a court-authorized inspection of Whipple](https://www.fox9.com/news/whipple-building-visit-findings-immigration-attorneys-feb-20-2026), documenting approximately 40 detainees with no blankets, pillows, or cots, piles of trash including rotten food, and a confusing phone system with unclear instructions for contacting legal representatives. DHS staff cut the tour short.
- **Feb 8** - Judge Brasel [ordered immigration attorneys be allowed inside](https://www.fox9.com/news/immigration-advocates-set-inspect-ice-headquarters-whipple-building-monday) the Whipple Building on Monday to visit clients and inspect conditions. The government argued detainees have no right to "unfettered" attorney access; attorneys requested permission to speak with detainees and bring recording equipment, which officials denied.
- **Feb 6** - Judge Blackwell [revealed that "the overwhelming majority of the hundreds seen by this court have been found to be lawfully present"](https://bringmethenews.com/minnesota-news/judge-says-most-cases-brought-to-him-by-ice-were-for-people-lawfully-in-minnesota) during a Feb 3 compliance hearing. He cited a specific case where a man arrested Jan 10 with no criminal history was ordered released Jan 15 but was not freed until Jan 28 — 13 days later — after being shuffled between detention centers in Texas and New Mexico. Le told the court she was instructed not to provide flight details because "the protesters will show up at the airport."

## Summary
The legal infrastructure around Operation Metro Surge began visibly collapsing in early February 2026. Jim Stolley, the chief counsel for ICE in Minnesota and a 31-year veteran of the agency, retired — his government email generating an automated reply that he had "retired from public service." His departure came days after ICE attorney Julie T. Le, on detail to the U.S. Attorney's Office, told U.S. District Judge Jerry Blackwell that the flood of cases had become unmanageable: "The system sucks. This job sucks." She was removed from her detail the next day. U.S. Attorney Daniel Rosen reported that 427 immigration lawsuits were filed in January alone, forcing his office to set aside much of its conventional work, with his civil division understaffed by roughly 50 percent. On February 6, U.S. District Judge Nancy Brasel gave the government until February 12 to reach agreement on ensuring the right to counsel for detainees at the Bishop Henry Whipple Federal Building, calling the gap between evidence and government claims "so enormous I don't know how you're going to close it." Immigration attorneys had filed 691 habeas corpus petitions since January 1 — five times the total for all of 2025.

## Sources
1. Chicago Tribune / AP (Feb 6, 2026): [Government must reach agreement on right to counsel for people at Minnesota ICE facility, judge says](https://www.chicagotribune.com/2026/02/06/government-agreement-right-to-counsel-minnesota-ice-facility/)
2. Courthouse News Service (Feb 6, 2026): [Judge blasts "enormous gap" in feds' defense over blocking detainees' access to counsel](https://www.courthousenews.com/judge-blasts-enormous-gap-in-feds-defense-over-blocking-detainees-access-to-counsel/)
3. KSTP (Jan 28, 2026): [Class action: ICE detainees at Whipple Building routinely denied access to counsel](https://kstp.com/kstp-news/top-news/class-action-ice-detainees-at-whipple-building-routinely-denied-access-to-counsel/)
4. CBS Minnesota (Jan 28, 2026): [Detainees at Whipple federal building in Minneapolis have been denied access to lawyer, suit says](https://www.cbsnews.com/minnesota/news/whipple-building-access-to-lawyer-denied/)
5. Democracy Forward (Jan 28, 2026): [The Advocates for Human Rights, Individual Detained in Minnesota Sue U.S. Department of Homeland Security Over Denial of Access to Lawyers](https://democracyforward.org/news/press-releases/the-advocates-for-human-rights-individual-detained-in-minnesota-sue-u-s-department-of-homeland-security-over-denial-of-access-to-lawyers/)
6. FOX 9 (Jan 2026): [Claims of ICE blocking immigration attorneys follows DHS playbook](https://www.fox9.com/news/claims-ice-blocking-immigration-attorneys-follows-dhs-playbook-jan-2026)
7. ABC News (Jan 18, 2026): [Lawyers allege Dept. of Homeland Security is denying legal counsel to Minnesota detainees](https://abcnews.go.com/US/lawyers-allege-dept-homeland-security-denying-legal-counsel/story?id=129335914)
8. Reason (Jan 22, 2026): [ICE turns lawyers away at Minneapolis detention facility](https://reason.com/2026/01/22/ice-turns-lawyers-away-at-minneapolis-detention-facility/)
9. CBS Minnesota (Feb 1, 2026): [Conditions inside Whipple Federal Building are "unacceptable," Minnesota lawmaker says after visit](https://www.cbsnews.com/minnesota/news/federal-whipple-building-ice-lawmakers-visit/)
10. FOX 9 (Feb 2026): [ICE detention conditions at Fort Snelling labeled 'inhumane'](https://www.fox9.com/news/ice-detention-conditions-fort-snelling-labeled-inhumane-feb-2026)
11. KSTP (Feb 2026): [Woodbury man describes conditions inside Whipple Building; Minnesota congresswoman investigating](https://kstp.com/kstp-news/top-news/woodbury-man-describes-conditions-inside-whipple-building-minnesota-congresswoman-investigating/)
12. Star Tribune (Jan 31, 2026): ['No humanity': Detainees describe conditions inside Whipple Federal Building](https://www.startribune.com/no-humanity-detainees-describe-conditions-inside-whipple-federal-building/601566788)
13. KSTP (Feb 6, 2026): [Rep. Morrison calls for Whipple detention center to be 'shut down' as peers are denied access](https://kstp.com/kstp-news/top-news/rep-morrison-calls-for-whipple-detention-center-to-be-shut-down-as-peers-are-denied-access/)
14. Star Tribune (Feb 5, 2026): [Rep. Kelly Morrison reports detainees in leg shackles, no clear plan to prevent measles at Whipple](https://www.startribune.com/kelly-morrison-tours-whipple-federal-building-fort-snelling-ice-detention-conditions/601578266)
15. MinnPost (Feb 2026): ['Cruel, unsafe, unlawful' conditions reported at Whipple](https://www.minnpost.com/glean/2026/02/cruel-unsafe-unlawful-conditions-reported-at-whipple/)
16. Minnesota Reformer (Feb 2026): [DHS again denies Minnesota members of Congress access to Whipple building](https://minnesotareformer.com/briefs/dhs-again-denies-minnesota-members-of-congress-access-to-whipple-building/)
17. Racket (Feb 2026): [How DHS Turned the Whipple Federal Building Into a House of Horrors](https://racketmn.com/how-dhs-turned-the-whipple-federal-building-into-a-house-of-horrors)
18. New York Times (Feb 7, 2026): [Top ICE Lawyer in Minnesota Departs as Immigration Lawsuits Overwhelm Courts](https://www.nytimes.com/2026/02/07/us/ice-lawyer-quits-minnesota.html)
19. NBC News (Feb 4, 2026): [Government attorney who told judge in ICE case, 'This job sucks,' removed from detail](https://www.nbcnews.com/politics/justice-department/attorney-government-tells-judge-ice-case-job-sucks-rcna257349)
20. CNN (Feb 4, 2026): [Trump admin attorney leaves Minnesota after telling judge her job 'sucks' amid crush of immigration cases](https://www.cnn.com/2026/02/04/politics/prosecutor-job-sucks-minnesota-hold-me-in-contempt)
21. CBS Minnesota (Feb 4, 2026): [ICE lawyer removed from Minnesota immigration detail after telling judge 'this job sucks'](https://www.cbsnews.com/minnesota/news/ice-lawyer-julie-le-this-job-sucks-minneapolis/)
22. FOX 9 (Feb 7, 2026): [ICE is frustrating judges and exhausting DOJ attorneys](https://www.fox9.com/news/ice-is-frustrating-judges-exhausting-its-own-attorneys)
23. NPR (Feb 5, 2026): [More frustrated prosecutors at the U.S Attorney's office in Minnesota call it quits](https://www.npr.org/2026/02/05/nx-s1-5702356/more-frustrated-prosecutors-at-the-u-s-attorneys-office-in-minnesota-call-it-quits)
24. ABC News (Feb 4, 2026): ['This job sucks,' overwhelmed DHS lawyer says in court hearing over ICE's response to court orders](https://abcnews.go.com/US/job-sucks-dhs-lawyer-court-hearing-ices-response/story?id=129855783)
25. Star Tribune (Feb 2, 2026): [Another wave of departures in Minnesota's U.S. Attorney's Office](https://www.startribune.com/another-wave-of-departures-in-minnesotas-us-attorneys-office/601575569)
26. Bring Me The News (Feb 6, 2026): [Judge: 'Overwhelming majority' of cases brought to him by ICE were for people lawfully in Minnesota](https://bringmethenews.com/minnesota-news/judge-says-most-cases-brought-to-him-by-ice-were-for-people-lawfully-in-minnesota)
27. Star Tribune (Feb 12, 2026): [Judge rules Whipple detainees must have access to attorneys, private calls](https://www.startribune.com/judge-rules-whipple-detainees-must-have-access-to-attorneys-private-calls/601581387)
28. AP (Feb 12, 2026): [A judge orders DHS to give Minnesota detainees swift access to lawyers before transfers](https://wtop.com/national/2026/02/a-judge-orders-dhs-to-give-minnesota-detainees-swift-access-to-lawyers-before-transfers/)
29. FOX 9 (Feb 10, 2026): [Immigration attorneys detail Whipple Building visit in court filings](https://www.fox9.com/news/whipple-building-visit-findings-immigration-attorneys-feb-20-2026)
30. CBS Minnesota (Feb 11, 2026): [Attorney who visited ICE holding facility says detainees need easier access to legal help](https://www.cbsnews.com/minnesota/news/whipple-building-conditions-lawsuit-inspection/)
31. Star Tribune (Feb 13, 2026): [Court ruling means Minnesota immigrants sent to Texas may have little chance of returning](https://www.startribune.com/court-ruling-means-minnesota-immigrants-sent-to-texas-may-have-little-chance-of-returning/601580036)
32. NBC News (Feb 9, 2026): [US appeals court upholds Trump administration's immigration detention policy](https://www.nbcnews.com/politics/immigration/us-appeals-court-upholds-trump-administrations-immigration-detention-p-rcna257883)
33. CNN (Feb 6, 2026): [Appeals court greenlights Trump admin policy of detaining undocumented immigrants without opportunity to seek release](https://www.cnn.com/2026/02/06/politics/appeals-court-trump-immigration-detention-policy)
34. CBS News (Feb 6, 2026): [Appeals court endorses Trump policy of holding many ICE detainees without bond hearings](https://www.cbsnews.com/news/appeals-court-endorses-trump-policy-of-holding-many-ice-detainees-without-bond-hearings/)
35. Sahan Journal (Feb 9, 2026): [Federal ruling allows immigrants to be held indefinitely in Texas](https://sahanjournal.com/immigration/texas-fifth-circuit-ruling-immigrants-indefinite-detention/)
36. MPR News (Feb 11, 2026): [Lawyers gain access to Whipple Federal Building after lawsuit, find lack of access to counsel](https://www.mprnews.org/story/2026/02/11/lawyers-gain-access-to-whipple-federal-building-after-lawsuit-find-lack-of-access-to-counsel)

## Related Incidents
- [Judge Orders ICE Director to Appear for Contempt; 96 Court Orders Violated](#2026-01-27-tobay-robles-lyons-contempt)
- [Attorneys Denied Access to Detained Clients at Whipple Building](#2026-01-15-whipple-lawyers-denied-access)
- [Congressional Representatives Denied Access to Whipple ICE Facility](#2026-01-10-congressional-access-denied)
- [DHS Response: Claims of "Subprime Conditions" at Whipple Are "FALSE"](#2026-02-07-dhs-response-whipple-conditions-false)
- [Protester Wes Prince Detained 9 Hours at Whipple Building](#2026-01-08-wes-prince-detained)
- [Patient Shackled to Hospital Bed by ICE for 28 Hours Without Warrant](#2025-12-31-hcmc-patient-shackled)

## The Legal System Collapses

### ICE Chief Counsel Retires
Jim Stolley, the chief counsel for ICE in Minnesota, left the agency in early February 2026 after 31 years of federal service. Emails sent to his government account generated an automated response noting that he had "retired from public service." Stolley oversaw a team of government lawyers who appear before immigration judges in Minnesota, where the surge of enforcement actions had generated an enormous caseload. DHS spokeswoman Tricia McLaughlin confirmed his retirement.

Former senior immigration judge Ryan Wood, who worked closely with Stolley for years, described him as "extremely bright" and indefatigable, known for keeping his desk immaculate and responding quickly to correspondence even as the caseload grew. "Those are going to be big shoes to fill because he had a lot of autonomy," Wood said.

Immigration law professor Linus Chan of the University of Minnesota called the departure a troubling sign: "It is never a good sign when experienced lawyers who have weathered several different presidential administrations decide to leave."

### "The System Sucks. This Job Sucks."
Days before Stolley's departure, ICE attorney Julie T. Le — a DHS lawyer on detail to the U.S. Attorney's Office since January 5 — told U.S. District Judge Jerry Blackwell during a February 4 hearing that the number of lawsuits filed by recently detained immigrants had become unmanageable. Le had been assigned 91 cases in under a month.

"What do you want me to do? The system sucks. This job sucks," Le told the judge after he expressed frustration over the government's failure to abide by court orders related to immigrants seeking release from custody. She sardonically suggested the judge hold her in contempt "so that I can have a full 24 hours of sleep." Le described getting ICE to follow court orders as "like pulling teeth," saying it took "10 emails from me for a release condition to be corrected."

Judge Blackwell responded that a court order is "not advisory, and it is not conditional," and that detention without legal authority constitutes "a constitutional injury." Le's detail to the U.S. Attorney's Office was terminated the next day. DHS Assistant Secretary Tricia McLaughlin characterized her courtroom statements as "unprofessional and unbecoming."

### U.S. Attorney's Office Overwhelmed
U.S. Attorney Daniel Rosen submitted a declaration as part of ongoing immigration litigation saying his office was struggling to cope with a "flood" of immigration cases. In January alone, more than 427 immigration lawsuits were filed, forcing the office to put aside much of its conventional work. The civil division, which handles those cases, was understaffed by roughly 50 percent. "Paralegals are continuously working overtime," Rosen wrote. "Lawyers are continuously working overtime."

The Minnesota U.S. Attorney's Office experienced a broader exodus of attorneys, dropping from approximately 70 assistant attorneys during the Biden administration to as few as 17. The departures were driven by frustration with the volume and nature of immigration enforcement operations stemming from Operation Metro Surge.

## The Lawsuit: Advocates for Human Rights v. DHS

### Case Details
- **Case name:** The Advocates for Human Rights et al v. U.S. Department of Homeland Security et al.
- **Court:** U.S. District Court, District of Minnesota
- **Judge:** U.S. District Judge Nancy Brasel
- **Filed:** January 28, 2026
- **Type:** Class action, seeking injunctive relief

### Plaintiffs
- **The Advocates for Human Rights** (Minneapolis-based nonprofit), represented by Democracy Forward and Fredrikson & Byron P.A.
- **L.H.M.** (named plaintiff, pseudonym) -- a St. Paul woman with a pending asylum case who was detained during a routine check-in at ICE's Office of Intensive Supervision in Bloomington. L.H.M. had recently undergone cranial surgery and had significant medical needs. Her attorney traveled to the Whipple Building immediately but was refused access.

### Defendants
- U.S. Department of Homeland Security
- Secretary of Homeland Security Kristi Noem
- Immigration and Customs Enforcement
- Acting ICE Director Todd Lyons

### Key Allegations
The lawsuit alleges that since January 11, 2026, detainees at the Whipple Building have not been provided "constitutionally adequate or statutorily compliant access to counsel." Specific allegations include:

- Detainees are not granted outgoing phone calls; they are told they will be allowed a call after being "booked," by which time they have been transferred to a detention facility outside the state.
- ICE agents refuse to let detainees call their immigration attorneys, ignore phone calls and emails from lawyers, and have threatened attorneys who attempted to enter the building.
- When phone calls are permitted, ICE personnel are typically nearby, undermining attorney-client confidentiality.
- Attorneys have been confronted by armed security personnel; one was threatened with arrest despite having received prior permission from agency officials.
- The facility lacks infrastructure for in-person attorney-client meetings, including private phones where privileged calls can be conducted.
- Detainees are pressured to sign "voluntary departure" (self-deportation) documents before accessing counsel.
- Swift transfers out of state prevent detainees from consulting lawyers and petitioning courts.

### Legal Claims
Violations of the Fifth and Sixth Amendment rights to due process and the right to consult with counsel, violations of federal law, denial of due process, and unauthorized use of a civilian federal building as a detention facility without required safeguards.

## February 6 Hearing

U.S. District Judge Nancy Brasel held a hearing on the temporary restraining order request on February 6, 2026. Key developments:

- Brasel told DOJ attorney Christina Parascandola there was a "very wide factual disconnect" between what the plaintiffs allege and the government's claims of adequate access.
- The government argued detainees have access to free, unmonitored phone calls. Plaintiffs submitted declarations from attorneys and detainees disputing that claim, saying calls take place within earshot of federal agents.
- Parascandola argued the Whipple Building is a "temporary holding facility" rather than a "detention center," and therefore lacks the infrastructure for face-to-face legal meetings.
- Brasel called the government's argument "a tough sell," noting there was far more evidence in the case record to back up the plaintiffs' claims than the government's assurances.
- Parascandola conceded she had never visited the Whipple Building.
- Brasel stated: "The gap here is so enormous I don't know how you're going to close it."
- The government presented a single declaration from a federal field office director. Plaintiffs presented a "mountain of evidence."
- Rather than ruling on the spot, Brasel ordered both sides to continue mediation with a retired judge who has been mediating and who has already helped narrow some gaps.
- **Deadline:** If no partial agreement is reached by 5 p.m. Thursday, February 12, Brasel will issue her order.
- Brasel also issued an order requiring the government to allow Justice Department attorneys to personally view conditions at the Whipple Building by Monday.

### Attorney Statements
- **Jeffrey Dubner** (plaintiffs' attorney): Stated detainees are allowed to make phone calls, but ICE personnel are typically nearby.
- **Michele Garnett McKenzie** (Executive Director, The Advocates for Human Rights): "Access to counsel is fundamental...when DHS restricts ability to speak confidentially with attorneys at crucial case moments, the result is unjustified detention."
- **Skye Perryman** (President/CEO, Democracy Forward): Called this "deliberate strategy to evade accountability...violating Constitution and federal law."

## February 9 Attorney Inspection

Days before the ruling, attorneys Kim Boche and Hanne Sandison of the Advocates for Human Rights conducted a court-authorized inspection of the Whipple Building on February 9. Boche filed a sworn declaration in federal court documenting the conditions they observed. Key findings:

- Approximately 40 detainees were held in seven rooms. No detainee had a blanket, pillow, sleeping pad, or cot.
- Piles of trash, including rotten apple cores and food wrappers, were visible on cell floors with no waste receptacles.
- A phone was available, but reaching an outside number required navigating lengthy multilingual prompts and dialing multiple numbers before connecting. Instructions for contacting legal representatives were unclear.
- One detainee reported living in the country for 10 years but having "no idea who to call for legal help."
- One woman reported freezing temperatures in her cell with no blankets. She lacked an attorney and had no family nearby.
- No informational materials explaining detainee rights were visible. Federal officials told the attorneys that all detainees received an informational handbook, but none were seen with one. Attorneys later noted the handbook contained limited information and was printed only in English.
- DHS staff cut the tour short.

## February 12 Ruling

On February 12, the deadline Brasel had set during the February 6 hearing, she issued a 41-page emergency restraining order. The court found that the government had likely violated the constitutional rights of detainees at the Whipple Building by systematically denying access to legal counsel.

### Key Provisions

Brasel ordered DHS to:

- Provide every detainee with the opportunity to contact an attorney within one hour of arrival at Whipple, before any transfer out of state.
- Give all detainees free, private, and unmonitored access to telephones, with no time limit and no restriction on the number of calls to counsel.
- Distribute a written notice in five languages outlining available legal services within one hour of detention.
- Allow attorney visitation seven days per week, with private meeting rooms provided.
- Impose a 72-hour moratorium on out-of-state transfers, during which detainees must be given access to counsel.
- Inform detainees of their transfer destination in advance and provide a phone call to notify legal counsel or family.
- Distribute notice of the order to all ICE and DHS personnel within 12 hours.

### Court Findings

Brasel wrote that the plaintiffs "have presented substantial, specific evidence detailing these alleged violations of the United States Constitution. In response, defendants offer threadbare declarations generally asserting, without examples or evidence, that ICE provides telephone access to counsel for noncitizens in its custody."

She stated that "in planning for Operation Metro Surge, the government failed to plan for the constitutional rights of its civil detainees," and rejected the government's argument that compliance would cause logistical difficulties: "The Constitution does not permit the government to arrest thousands of individuals and then disregard their constitutional rights because it would be too challenging to honor those rights."

### Temporary Status

The order is temporary, effective until Friday, February 26, 2026 at 5:00 p.m. CST. A status conference is scheduled for February 24 to assess DHS compliance and determine whether further proceedings are necessary.

### Reactions

Michele Garnett McKenzie, executive director of the Advocates for Human Rights: "When the government deprives people of liberty, it cannot avoid its constitutional responsibilities because it finds them inconvenient. It's appalling that we required a court ruling to defend this fundamental right."

Skye Perryman, president and CEO of Democracy Forward: "The government has been detaining people in a building never meant for long-term custody, shackling them, secretly transferring them out of state, and blocking access to counsel and oversight in a deliberate effort to evade accountability. Access to a lawyer is not optional; it is a fundamental right in America."

DHS provided a statement that had been prepared before the ruling, claiming all detainees receive due process and access to legal counsel: "No lawbreakers in the history of human civilization have been treated better than illegal aliens in the United States."

## Documented Conditions at Whipple Building

The lawsuit and court proceedings take place against a backdrop of extensively documented conditions at the facility. The Bishop Henry Whipple Federal Building was designed as a temporary holding facility for stays under 12 hours, but has been used to hold people for days during Operation Metro Surge.

### Physical Conditions
- **No beds.** Detainees sleep on concrete floors with only thin foil emergency blankets, or no blankets at all.
- **Overcrowding.** Cells with 20-person capacity packed with 100 or more people. One cell meant for 30 held approximately 130. Detainees forced to sleep standing up or take turns lying down.
- **Constant shackling.** Detainees walk around in leg shackles at all times.
- **Temperature.** Cold temperatures with vents blowing cold air continuously. Detainees describe being "freezing on the floor."
- **Sanitation.** Overflowing toilets. Detainees must use toilets in front of everyone. Trash strewn about. No hygiene products provided.
- **Food.** Meals consist of one sandwich per day. Minimal food provided.

### Medical Care
- No specific medical policy and no real medical care on-site.
- One nurse present from 8 a.m. to 10 p.m. during some periods; no doctor or nurse on-site during some congressional visits.
- No complete medical exam unless detainees are sent to Texas.
- No medical assessment at intake.
- No protocol to prevent the spread of measles between Texas and Minnesota facilities.
- Detainee Hani Duglof, who has epidermolysis bullosa (a rare skin condition), had shackles and concrete floor contact cause blistering complications. He was hospitalized for two days while remaining in ICE custody with legs shackled, then returned with an active infection.

### Access to Legal Counsel
- Attorneys denied access to clients under various pretexts: no appointment, client did not request attorney by name, facility "cannot accommodate" visits.
- One ICE agent told an attorney: "If we let you see your clients, we would have to let all the attorneys see their clients, and imagine the chaos."
- An anonymous immigration attorney who had visited clients at Whipple for a decade without issue described the denials as "new and unprecedented."
- Attorney Robert Sicoli, a criminal defense attorney with nearly 20 years of practice in Minnesota, stated: "I have never been denied access to a client."
- Immigration attorney David Wilson reported detainees could be "gone by dinner time" after being picked up, transferred out of state before lawyers could reach them.

### Congressional Access
- **Jan 10:** Reps. Ilhan Omar, Angie Craig, and Kelly Morrison ordered to leave approximately 10 minutes after being granted entry. During brief visit, observed approximately 20 detainees sitting with heads in their hands.
- **Feb 1:** Morrison conducted oversight visit, observing leg shackles, no beds, cold concrete floors, no medical protocols, and an inability to determine total detainee count.
- **Feb 5-6:** Morrison toured the facility three times, calling conditions "very dehumanizing" and calling for the facility to be "shut down."
- **Feb 6:** Reps. Angie Craig and Betty McCollum denied entry during unannounced oversight visits -- their second denial.
- Morrison (a medical doctor) described conditions as "akin to a Third World prison."
- Senators Amy Klobuchar and Tina Smith characterized conditions as "shocking and inhumane."

### DHS Playbook
FOX 9 reported that the attorney-blocking tactics at Whipple mirror methods used at a Santa Ana, California facility in 2025, where agents denied phone access and private meeting rooms, relocated detainees without notice, and continued denying access even after court orders required seven-day-per-week attorney access.

## Official Accounts

### DHS Statement on Counsel Access
DHS spokesperson: "Any allegations people detained by ICE do not have access to attorneys are FALSE. All detainees have opportunities to communicate with their family members and lawyers. Illegal aliens in detention have access to phones they can use to contact their families and lawyers. ICE gives all illegal aliens arrested a court-approved list of free or low-cost attorneys. All detainees receive full due process."

All attorneys ABC News spoke to called the DHS denial "a blatant lie."

### DHS Statement on Conditions
DHS told the New York Times that detainees receive "proper meals, medical treatment" and communication access. A separate DHS statement claimed: "This is the best healthcare many aliens have received in their entire lives."

### Homan Response
Border Czar Tom Homan stated "conditions looked fine" during his own visit and credited improved circumstances to more targeted arrests.

### Congressional Response
Reps. Angie Craig and Betty McCollum (after being denied access Feb 6): "We will continue to demand transparency...and fight this administration's cruel and lawless immigration enforcement actions."

Minnesota Senators Klobuchar and Smith stated that due process and counsel rights are "foundational constitutional guarantees enshrined in the Fifth and Sixth Amendments."

## Legal Context

### Habeas Corpus Filings
Since January 1, immigration attorneys in Minnesota have filed more than 840 habeas corpus petitions seeking to have their clients released, compared to 128 total filings over the entire year of 2025. Federal courts have been overwhelmed with wrongful detention petitions in recent weeks.

### ICE Detention Standards
ICE's own National Detention Standards require legal visitation seven days per week for a minimum of eight hours on business days and four hours on weekends.

### Related Legal Proceedings
Multiple federal judges have issued orders in related cases requiring DHS to return detainees who were transferred out of state in violation of court orders. The pattern of "repeated violations of court orders" has been documented across multiple cases in the District of Minnesota.

### Fifth Circuit Upholds Mandatory Detention Without Bond
On February 6, the Federal Court of Appeals for the Fifth Circuit in New Orleans upheld the Trump administration's policy that anyone who entered the U.S. without permission is not eligible for bond, in a 2-1 ruling. The decision covers Texas, Louisiana, and Mississippi — states that are home to some of ICE's largest detention facilities, including Camp East Montana at Fort Bliss in El Paso, where the vast majority of Minnesota detainees are sent.

Judge Edith Jones, appointed by President Ronald Reagan, wrote the majority opinion, agreeing with the government's argument that past practice "has little to do with the statute's text." The majority held that noncitizens in the interior of the country are "seeking admission" and thus not entitled to bond hearings by statute. Judge Kyle Duncan, a Trump appointee, joined the opinion. Judge Dana Douglas, a Biden appointee, dissented, warning the ruling could result in mandatory detention without bond for two million noncitizens.

The decision upends 30 years of legal precedent of allowing immigrants who were not deemed dangerous or a flight risk to remain free while their cases worked through court. Entering the U.S. without permission is a crime, but mandatory detention was previously reserved for immigrants caught crossing the border. That changed in July 2025 when immigration judges started denying bond hearings for anyone who had entered the country illegally, even if they had been living in the U.S. for years. The new policy helped drive nationwide detention numbers to 70,000 by the end of January 2026.

Over 300 federal judges nationally have ruled that the administration's mandatory detention policy is illegal, with only a handful siding with the administration. The Fifth Circuit ruling was the first time an appeals court upheld the policy.

Julia Decker, policy director for the Immigrant Law Center of Minnesota, said the administration's policies increasingly make it difficult for immigrants to pursue their legal cases. "We are really at a disadvantage when people are sent out of state and are in another jurisdiction," Decker said. "The odds stack up."

David Wilson, a Minneapolis attorney who is part of a nationwide group challenging mandatory detention, said they are requesting a "rehearing before the full Fifth Circuit because the position taken in that case is inconsistent with almost the entirety of the federal judicial system." Attorneys also worry a similar legal action is headed to the Eighth Circuit, which includes Minnesota and six other states. They expect the matter to eventually reach the U.S. Supreme Court.

### Texas Detention Conditions
Thousands of immigrants detained during Operation Metro Surge have been sent to Texas detention facilities, primarily to El Paso. Flight trackers estimate 3,000 immigrants have been sent out of state since January 1. Nick Benson, an activist and professional flight tracker who monitors chartered jets leaving MSP, said detainees are "pretty much all going to El Paso."

A young man from the Twin Cities in the process of applying for asylum told the Star Tribune he was held at a Texas detention facility in unsanitary conditions with no privacy to shower or use the bathroom. More than 60 people were crammed into a cell, toilets routinely overflowed, and he had to sleep curled up on the floor without a blanket. "The smell was intolerable," he said. "I felt embarrassed being there because of the way we were treated." Guards ignored detainees' requests for medical care.

In a February 10 court filing, attorneys Kim Boche and Hanne Sandison of the Advocates for Human Rights said they visited the Whipple Building and saw a room labeled "flight" full of detainees heading to Texas. Boche said several detainees told her they had not been able to talk with an attorney.

Three people, including one from Minnesota — [Victor Manuel Díaz](/entry/2026-01-14-victor-diaz-custody-death), arrested in Coon Rapids — have died in Texas detention facilities since December.

## Detainee Accounts

### L.H.M. (Named Plaintiff)
A St. Paul woman with a pending asylum case, detained during a required check-in. She had recently undergone cranial surgery with significant medical needs. Her attorney was refused access.

### 19-Year-Old Minnesota Resident (from lawsuit)
"I was never offered a lawyer at any point." Described being thrown to the ground despite not resisting, held in overcrowded cells, shackled, then transferred out of state without notification of destination.

### Refugee Living in Minneapolis (from lawsuit)
Described detention in a room with nearly 100 people, forced to sleep standing near an overflowing toilet. "It's like they're trying to drive you crazy...Most of them treated us like animals." ICE personnel refused legal consultation despite his protected refugee status.

### Hani Duglof, 32, Woodbury (from KSTP)
Arrested January 10 while driving to make food deliveries. Placed in a cell with approximately 30 people, legs shackled. His rare skin condition (epidermolysis bullosa) caused blisters from contact with shackles and concrete. "No bed, no mattress, just concrete." A vent blew cold air continuously. "My skin was cracking down. It was really cold." An overflowing toilet produced an overpowering smell.

### Unnamed Detained Women (from CBS Minnesota)
Reported to Rep. Morrison that they were sleeping on cold floors. "They're not treating us like human beings."

### Aliya Rahman, Minneapolis (from MinnPost)
"I saw Black and brown bodies shackled together, chained together, being marched by yelling agents outdoors." Noted agents refer to detainees as "bodies."
