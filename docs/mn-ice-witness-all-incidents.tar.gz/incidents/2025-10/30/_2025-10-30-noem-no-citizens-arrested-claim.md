---
date: 2025-10-30
time: unknown
location: DHS Press Conference, Gary, Indiana
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-14T20:26:03
last_updated: 2026-01-14T20:26:03
search_tags: us-citizen, src:npr, src:other-national
---

# DHS Secretary Noem: "No American Citizens Have Been Arrested or Detained"

## Summary
DHS Secretary Kristi Noem stated at a press conference that "no American citizens have been arrested or detained" by immigration agents. Multiple fact-checking organizations disputed this claim, including PolitiFact, NPR, and Poynter. ProPublica documented over 170 cases of U.S. citizens detained by immigration agents nationwide.

## Sources
1. Facebook Video (Oct 30, 2025): [Noem: "No citizens arrested or detained"](https://www.facebook.com/share/r/182qPHAp7o/)
2. YouTube Video (Oct 30, 2025): [Noem Statement](https://www.youtube.com/watch?v=0KiGZZD11bw)
3. PolitiFact (Oct 31, 2025): [PolitiFact Fact-Check](https://www.politifact.com/factchecks/2025/oct/31/kristi-noem/immigration-ICE-arrest-US-citizen-Chicago/)
4. Poynter (Nov 1, 2025): [Has ICE Arrested American Citizens?](https://www.poynter.org/fact-checking/2025/has-ice-arrested-american-citizens/)
5. NPR (Nov 5, 2025): [NPR Fact-Check: Noem on ICE Detaining US Citizens](https://www.npr.org/2025/11/05/nx-s1-5598373/npr-fact-checks-kristi-noem-on-ice-detaining-us-citizens)
6. ProPublica (2025): [More Than 170 U.S. Citizens Detained by ICE Agents](https://www.propublica.org/article/immigration-dhs-american-citizens-arrested-detained-against-will)

## Noem's Statement

### The Claim (October 30, 2025)
At a press conference in Gary, Indiana, Secretary Noem stated:

> "There's no American citizens have been arrested or detained. We focus on those that are here illegally."

> "And anything that you would hear or report that would be different than that is simply not true and false reporting."

## Fact-Check Results

### PolitiFact Assessment
PolitiFact, part of the Poynter Institute, found Noem's claim to be inaccurate. They noted that lawsuits, news reports, and even DHS's own statements contradict the claim.

### NPR Analysis
NPR concluded: "It is not true, and there's plenty of evidence that it's false. Many news outlets, including NPR, have reported on and spoken with U.S. citizens who've been arrested or temporarily detained by immigration agents."

### ProPublica Investigation
ProPublica documented **over 170 cases** of U.S. citizens arrested by federal immigration officers nationwide during the Trump administration — and noted this is likely an undercount.

## Documented Cases of U.S. Citizens Detained

| Name | Location | Duration | Details |
|------|----------|----------|---------|
| George Retes | California | 3 days | Army veteran zip-tied and held during farm raid |
| Julio Noriega | Illinois | Overnight | Released after officers found ID in his wallet |
| Jose Hermosillo | New Mexico | ~10 days | Has intellectual disability; released after family provided birth certificate |
| Debbie Brockman | Chicago | Hours | TV station employee; released without charges |
| Steve Held | Illinois | Hours | Journalist arrested at ICE protest; released without charges |
| Juan Carlos Lopez Gomez | Florida | Days | 20-year-old Georgia-born citizen; charges dismissed after mother presented documents |
| Cary López Alvarado | California | Same day | Pregnant U.S. citizen detained during Hawthorne raid |
| Leonardo Garcia Venegas | Alabama | ~1 hour | Handcuffed despite showing REAL ID driver's license |
| Chicago apartment residents | Chicago | Overnight | Dozens of U.S. citizens detained in single raid (late September) |

## Government Position

### DHS Response
DHS has previously acknowledged temporarily detaining U.S. citizens but claims:
- Agents do not intentionally target U.S. citizens.
- Citizens are released once their legal status is verified.
- Any detentions are brief and incidental.

### Judicial Assessment
U.S. District Court Judge Sara Ellis addressed DHS credibility in a 233-page ruling:

> "Every minor inconsistency adds up, and at some point, it becomes difficult, if not impossible, to believe almost anything that Defendants represent."

## Congressional Scrutiny
Noem's claims led to congressional investigations. Democratic members of the House Oversight Committee sent a formal letter to Secretary Noem demanding explanations for the documented citizen detentions.
