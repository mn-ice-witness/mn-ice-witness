---
date: 2026-01-08
time: unknown
location: Minneapolis
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-16T21:36:57
last_updated: 2026-01-16T21:36:57
search_tags: observer-intimidated, excessive-force, shooting, src:other-national
---

# ICE Agent Points Gun at Protester's Face at Point-Blank Range

## Summary
During protests in Minneapolis following the fatal shooting of Renee Good, video footage captured an ICE agent pointing a gun at a protester at point-blank range. The incident occurred on Thursday, January 8, 2026, the day after Good was killed.

## Sources
1. X Video (Jan 8, 2026): [Middle East Eye: ICE agent points gun at protester](https://x.com/MiddleEastEye/status/2009610981714931841/video/1)
2. Peoples Dispatch (Jan 11, 2026): [Movement against ICE grows in the US](https://peoplesdispatch.org/2026/01/11/movement-against-ice-grows-in-the-us-in-the-wake-of-killing-of-renee-good/)

## Affected Individual(s)
- **Name:** Unknown
- **Citizenship:** Unknown
- **Background:** Protester at Minneapolis demonstrations

## Timeline
- **January 7, 2026** - Renee Good fatally shot by ICE agent Jonathan Ross.
- **January 8, 2026** - Protests erupt across Minneapolis; ICE agent points gun at protester's face during demonstration.

## Related Incidents
- [Border Patrol Chief Bovino and Agents Tear Gas Protesters at Whipple](/entry/2026-01-08-whipple-tear-gas-renee-good-protest) — Tear gas, chemical agents, and shoving of protesters at Whipple the same morning
- [Renee Good Fatally Shot by ICE Agent](/entry/2026-01-07-renee-good-shooting) — Good's killing the previous day prompted the protests
