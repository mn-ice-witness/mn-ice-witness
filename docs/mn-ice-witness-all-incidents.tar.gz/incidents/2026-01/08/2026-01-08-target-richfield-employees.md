---
date: 2026-01-08
time: unknown
location: Target Store, 6445 Richfield Pkwy
city: Richfield
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: serious
created: 2026-01-14T08:01:12
last_updated: 2026-01-14T08:01:12
search_tags: us-citizen, citizen-check, excessive-force, workplace-raid, src:bring-me-the-news, src:star-tribune, src:kare11, src:wcco, src:sahan-journal, src:cnn, src:nbc, src:other-national, src:mpr
---

# Two U.S. Citizen Target Employees Detained and Injured

## Summary
Two Target drive-up employees, both U.S. citizens, were aggressively detained by CBP agents at the Richfield Target store. Both sustained injuries. According to witnesses, agents asked the workers if they were citizens; when they didn't answer and tried to go inside, they were grabbed and pinned to the ground. One affected individual, a 22-year-old Latino man identified in court documents as "Javier Doe," had a knee pressed into his neck, was driven around in an SUV while agents played loud music, and was eventually dumped in a Walmart parking lot in Bloomington. He required emergency medical care and is now a plaintiff in the ACLU class-action lawsuit against ICE.

## Sources
1. Bring Me The News Video (Jan 8, 2026): [Border agents descend on Richfield Target](https://bringmethenews.com/minnesota-news/video-border-agents-descend-on-richfield-target-store-arrest-drive-up-workers)
2. X Video (Jan 9, 2026): [Witness account](https://x.com/Peace_within_00/status/2010857759957229693)
3. Bring Me The News (Jan 11, 2026): [Protesters demand action after ICE arrests of U.S. citizen Target employees](https://bringmethenews.com/minnesota-news/protesters-demand-action-after-ice-arrests-of-u-s-citizen-target-employees)
4. Star Tribune (Jan 12, 2026): [Target employees detained by federal officers were U.S. citizens](https://www.startribune.com/target-employees-federal-arrest-border-patrol-renee-nicole-good-shooting-ice-crackdown-minneapolis/601562858)
5. Newsweek (Jan 9, 2026): [US citizens "aggressively" detained by CBP while working at Target](https://www.newsweek.com/us-citizens-aggressively-detained-border-patrol-working-target-11349481)
6. KARE 11 (Jan 8, 2026): [Federal agents take 2 into custody at Richfield Target](https://www.kare11.com/article/news/local/ice-in-minnesota/federal-agents-richfield-target/89-074f28c7-c04f-4392-9165-08ca304b0f39)
7. Star Tribune (Jan 9, 2026): [ACLU sues feds over alleged racial profiling in Twin Cities immigration surge](https://www.startribune.com/aclu-sues-feds-over-alleged-racial-profiling-in-twin-cities-immigration-surge/601564707)
8. NBC News (Jan 9, 2026): [Lawsuit accuses federal agents of racial profiling in Minneapolis immigration operation](https://www.nbcnews.com/news/us-news/lawsuit-accuses-federal-agents-racial-profiling-minneapolis-immigratio-rcna254245)
9. Common Dreams (Jan 9, 2026): [Trump's DHS Sued to End Lawless Stops and Arrests in Minnesota](https://www.commondreams.org/news/trump-s-dhs-sued-to-end-lawless-stops-and-arrests-in-minnesota)
10. CBS Minnesota (Jan 15, 2026): [Community members urge Target to stand with Minnesotans](https://www.cbsnews.com/minnesota/news/richfield-target-ice-immigration-raid-corporate-minneapolis/)
11. Bring Me The News (Jan 15, 2026): [Target silent after federal agents arrest employees](https://bringmethenews.com/minnesota-news/target-silent-after-federal-immigration-agents-arrest-twin-cities-employees-operate-near-stores)
12. Bring Me The News (Jan 15, 2026): [Pattern emerging of ICE targeting civilians at retail stores](https://bringmethenews.com/minnesota-news/pattern-emerging-of-ice-targeting-civilians-at-twin-cities-retail-stores)
13. Sahan Journal (Jan 15, 2026): [ACLU federal lawsuit coverage including Javier Doe](https://sahanjournal.com/immigration/aclu-federal-lawsuit-ice-minnesota/)
14. CNN Live Updates (Jan 15, 2026): [National live coverage](https://www.cnn.com/us/live-news/minneapolis-ice-shooting-protests-01-15-26)
15. ACLU Press Release (Jan 15, 2026): [ACLU sues federal government](https://www.aclu.org/press-releases/aclu-sues-federal-government-to-end-ice-cbps-practice-of-suspicionless-stops-warrantless-arrests-and-racial-profiling-of-minnesotans)
16. Instagram Video (Jan 8, 2026): ["Target employee detained by ICE"](https://www.instagram.com/reel/DTY9Em3ASMU/)
17. Instagram Video (Jan 8, 2026): ["A viral video reporting ICE arresting two US citizens"](https://www.instagram.com/reel/DTRPG3rjert/)
18. Court Filing (Jan 9, 2026): [Hussen v. Noem, Case 26-cv-00324 — Complaint including Javier Doe declaration](https://storage.courtlistener.com/recap/gov.uscourts.mnd.230424/gov.uscourts.mnd.230424.2.0.pdf)
19. MPR News (Feb 2, 2026): [Protesters call on Target to speak out against ICE](https://www.mprnews.org/story/2026/02/02/protesters-call-on-target-to-speak-out-against-ice)

## Affected Individual(s)

### Affected Individual 1: "Javier Doe" (ACLU lawsuit plaintiff)
- **Name:** "Javier Doe" (pseudonym used in lawsuit for protection)
- **Age:** 22
- **Residence:** Richfield, MN
- **Occupation:** Target drive-up employee
- **Citizenship:** U.S. Citizen (born in Minnesota, lived in Minnesota his entire life)
- **Ethnicity:** Latino/Hispanic
- **Injuries:** Head injury from being slammed into SUV; required emergency medical care

### Affected Individual 2
- **Name:** Not disclosed (shouted his name on video)
- **Occupation:** Target drive-up employee
- **Citizenship:** U.S. Citizen
- **Injuries:** Sustained injuries during detention

## Timeline
- **Unknown time** - CBP agents approach Target store at 6445 Richfield Pkwy
- **Shortly after** - Agents approach workers outside, ask if they are citizens
- **Workers don't answer** - Try to go inside the store
- **Immediately** - Agents grab workers, pin them to ground in store entranceway
- **During detention** - One man shouts his name and that he's a U.S. citizen
- **Javier Doe's detention:**
  - Tackled after telling agents he didn't have to answer citizenship questions
  - Handcuffed with knee pressed into his neck
  - Head slammed into SUV
  - Driven around in SUV while agents played loud music
  - Released in Walmart parking lot in Bloomington after passport reviewed
- **Same day** - Other individual detained for "large part of the day" then released
- **Later** - Javier Doe seeks emergency medical care for injuries

## Constitutional Violations Alleged (ACLU Lawsuit)
- **Fourth Amendment:** Unreasonable seizure and excessive force
- **First Amendment:** Retaliation for asserting constitutional rights
- **Equal Protection:** Racial profiling based on ethnicity
- **Fifth Amendment:** Violation of right to remain silent

## Official Accounts

### DHS Statement
"This individual was arrested for assaulting federal law enforcement officers."

In response to ACLU lawsuit, DHS spokesperson called the allegations "disgusting, reckless, and categorically FALSE."

### Rep. Michael Howard (DFL-Richfield)
"Both are U.S. Citizens, clearly targeted because of the color of their skin. Both have now been released, but sustained injuries and untold trauma while their rights were trampled for no reason whatsoever."

### ACLU Statement
Catherine Ahlin-Halverson, staff attorney with ACLU of Minnesota: "ICE and CBP's practices are both illegal and morally reprehensible. Federal agents' conduct—sweeping up Minnesotans through racial profiling and unlawful arrests—is a grave violation of Minnesotans' most fundamental rights."

## Witness Accounts
Video shows large number of CBP agents approaching and entering Target. In the entranceway, agents pinned two men to ground who, according to witnesses, were drive-up employees. One man is heard shouting he's a U.S. citizen.

## Legal Action
Javier Doe is one of three plaintiffs in ACLU of Minnesota's class-action lawsuit filed January 15, 2026:
- **Case:** Filed in federal court
- **Defendants:** DHS Secretary Kristi Noem, ICE Director Todd Lyons
- **Relief sought:** Statewide injunction against racial profiling and excessive force

## Aftermath
- Protesters gathered at store demanding Target protect employees
- Pattern emerging of ICE targeting civilians at Twin Cities retail stores
- Target has remained silent on the incidents
- Javier Doe now ACLU lawsuit plaintiff
