---
date: 2026-01-08
time: daytime
location: Gates of Rochester complex and various locations
city: Rochester
type: immigrants
status: ongoing
affected_individual_citizenship: various
injuries: none
created: 2026-01-14T09:04:50
last_updated: 2026-01-14T09:04:50
search_tags: warrantless-entry, src:other-local
---

# Multiple ICE Arrests in Rochester; Activist Documents Agent Using Hammer on Car Window

## Summary
ICE conducted enforcement operations across Rochester on January 8-9, 2026, with at least 5 confirmed arrests (27 total arrests in Rochester according to DHS). Activists witnessed concerning tactics including an agent using a hammer to try to open a car window during a warrantless detention. Mayor Kim Norton said the city did not ask for or want ICE presence.

## Sources
1. KTTC (Jan 9, 2026): [Federal immigration agents conduct arrests in Rochester](https://www.kttc.com/2026/01/09/federal-immigration-agents-conduct-arrests-rochester/)
2. KTTC (Jan 12, 2026): [30 detained by ICE in SE Minnesota, NE Iowa according to 'worst of the worst' webpage](https://www.kttc.com/2026/01/12/30-detained-by-ice-se-minnesota-ne-iowa-according-worst-worst-webpage/)
3. Post Bulletin (Jan 9, 2026): [Increased ICE presence being reported in Rochester](https://www.postbulletin.com/news/local/increased-ice-presence-being-reported-in-rochester)
4. KIMT (Jan 9, 2026): [ICE agents arrest man outside of KIMT News 3 studios](https://www.kimt.com/news/ice-agents-arrest-man-outside-of-kimt-news-3-studios/article_71ba9ac0-3beb-457d-9318-66e65bf74842.html)

## Number of Arrests
- **COPAL MN-Rochester confirmed:** 5 arrests as of 3 p.m. on January 8th
- **DHS 'worst of the worst' webpage:** 27 arrests in Rochester
- **Regional total (SE Minnesota + NE Iowa):** 30 detained

## Locations of Activity
- Gates of Rochester apartment complex
- Outside KIMT News studio
- Various locations throughout the city

## Witness Accounts

### David Perdono (COPAL SE MN Lead Organizer)
Witnessed concerning behavior including "one case where there was no warrant and someone was detained, with an officer having 'a hammer in his hand trying to open this person's window.'"

### KIMT Reporter Ryan Juntti
Captured video of an arrest outside the KIMT News studio. The agent told him it was "targeted enforcement."

## Community Response
Activists and observers followed agents while:
- Taking video
- Blowing whistles
- Honking car horns
- Alerting residents of their presence

## Official Statements

### Mayor Kim Norton
"We have not asked for, nor do we want or need ICE in Rochester. We live in a wonderfully caring and safe community…but they are here anyway."

### Rochester Police Department
RPD was not informed of ICE operations but observed agents in the city. RPD is not involved in immigration enforcement and defers to federal agents.

## Context
These arrests came one day after the fatal shooting of Renee Good in Minneapolis, amid escalating tensions across the state.
