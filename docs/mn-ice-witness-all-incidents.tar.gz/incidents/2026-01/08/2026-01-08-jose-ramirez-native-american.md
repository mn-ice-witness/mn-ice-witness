---
date: 2026-01-08
time: 11:00
location: Hy-Vee, Robbinsdale
city: Robbinsdale
type: citizens
status: ongoing
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-14T08:01:12
last_updated: 2026-01-28T21:35:17
search_tags: us-citizen, native-american, excessive-force, citizen-check, vehicle-pursuit, src:star-tribune, src:fox9, src:wapo, src:sahan-journal, src:mpr, src:other-local, src:other-national
---

# Native American U.S. Citizen Punched and Detained by ICE

## Updates
- **Jan 26** - Ramirez [voluntarily turned himself in](https://www.kaxe.org/minnesota-news/2026-01-28/red-lake-nation-descendant-charged-with-assaulting-ice-agent-during-detainment) after ICE returned to his home twice threatening arrest "the easy way or the hard way." He was charged under 18 USC 111 for allegedly assaulting an agent during his Jan 8 detention; released same afternoon.
- **Jan 27** - [NARF calls charges "retaliation"](https://www.mprnews.org/story/2026/01/27/native-american-legal-rights-group-says-jose-roberto-ramirez-retaliated-against-by-ice) for speaking publicly about his wrongful detention. Attorney Jacqueline De León: "It is deeply offensive and ironic that the first people of this land would be subjected to questions around their citizenship."

## Summary
Jose Roberto "Beto" Ramirez, 20, U.S. citizen and Red Lake Nation descendant, was punched and detained by ICE while driving to visit his aunt. Told he "wasn't from here." Released after family brought passport/birth certificate.

## Sources
1. Star Tribune (Jan 9, 2026): [U.S. citizen arrested by ICE in Twin Cities immigration operation](https://www.startribune.com/us-citizen-arrested-ice-day-after-fatal-shooting-renee-good-twin-cities-immigration-operation/601560460)
2. ICT News (Jan 9, 2026): ['I felt like I was kidnapped': Ojibwe man recounts ICE detainment](https://ictnews.org/news/i-felt-like-i-was-kidnapped-ojibwe-man-recounts-ice-detainment/)
3. Native News Online (Jan 10, 2026): [Red Lake man kidnapped by ICE](https://nativenewsonline.net/currents/red-lake-man-kidnapped-by-ice)
4. Washington Post (Jan 15, 2026): [Native Americans are being swept up by ICE in Minneapolis, tribes say](https://www.washingtonpost.com/politics/2026/01/15/native-americans-ice-minneapolis/)
5. The Mirror (Jan 15, 2026): [ICE 'punches' Native American before making 'arrest taunt'](https://www.themirror.com/news/us-news/native-american-detained-ice-minnesota-1609397)
6. Sahan Journal (Jan 15, 2026): [Minnesotans increasingly see racial profiling from ICE agents](https://sahanjournal.com/immigration/ice-racial-profiling-minnesota-citizens-detained/)
7. FOX 9 (Jan 15, 2026): [Oglala Sioux leaders seek missing members detained by ICE in Minneapolis](https://www.fox9.com/news/oglala-sioux-leaders-seek-missing-members-detained-ice-minneapolis)
8. The Daily Beast (Jan 12, 2026): [Yet Another ICE Nightmare Unfolds Miles Away From Renee Nicole Good Shooting](https://www.thedailybeast.com/yet-another-ice-nightmare-unfolds-miles-away-from-renee-nicole-good-shooting-in-minnesota/)
9. Facebook Video (Jan 8, 2026): [Aunt's Facebook Live of arrest - original audio](https://www.thedailybeast.com/yet-another-ice-nightmare-unfolds-miles-away-from-renee-nicole-good-shooting-in-minnesota/)
10. X Video (Jan 8, 2026): [X post with arrest footage](https://x.com/LongTimeHistory/status/2009499306676322337)
11. Star Tribune (Jan 18, 2026): [Allegations of racial profiling of U.S. citizens on the rise as ICE surge expands in Minnesota](https://www.startribune.com/allegations-of-racial-profiling-of-us-citizens-on-the-rise-as-ice-surge-expands-in-minnesota/601564653)
12. KAXE (Jan 28, 2026): [Red Lake Nation descendant charged with assaulting ICE agent during detainment](https://www.kaxe.org/minnesota-news/2026-01-28/red-lake-nation-descendant-charged-with-assaulting-ice-agent-during-detainment)
13. MPR News (Jan 27, 2026): [Native American legal rights group says Jose Roberto Ramirez retaliated against by ICE](https://www.mprnews.org/story/2026/01/27/native-american-legal-rights-group-says-jose-roberto-ramirez-retaliated-against-by-ice)

## Affected Individual(s)
- **Name:** Jose Roberto "Beto" Ramirez
- **Age:** 20
- **Citizenship:** U.S. Citizen (born Minneapolis)
- **Heritage:** Red Lake Nation (Ojibwe) descendant
- **Mother:** Raelyn Duffy (Red Lake Nation member)

## What Happened
- Followed by blacked-out SUV
- ~20 agents swarmed vehicle at Hy-Vee
- Punched while face being scanned
- Told "You're gonna see your family, some of your cousins in here"
- Threatened with federal prison for "assaulting officer" (charges filed Jan 26)
- Handcuffs tightened when asked to loosen
- Still bruised 24+ hours later
