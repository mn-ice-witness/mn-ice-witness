---
date: 2026-01-27
time: morning
location: Minneapolis suburb
city: Minneapolis
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-30T14:27:01
last_updated: 2026-01-30T14:27:01
search_tags: us-citizen, citizen-check, src:mpr
---

# U.S. Citizen Luis Martinez Subjected to Facial Recognition Scan

## Summary
Luis Martinez, a U.S. citizen, was boxed in by federal agents in a Minneapolis suburb while driving to work. Masked agents demanded his ID, then held a phone inches from his face and scanned his features using the Mobile Fortify facial recognition app. He was only released after producing his U.S. passport.

## Sources
1. MPR News (Jan 30, 2026): [DHS ramps up surveillance in immigration raids, sweeping in citizens](https://www.mprnews.org/story/2026/01/30/dhs-ramps-up-surveillance-in-immigration-raids-sweeping-in-citizens)

## Affected Individual(s)
- **Name:** Luis Martinez
- **Citizenship:** U.S. citizen
- **Situation:** Stopped while driving to work
