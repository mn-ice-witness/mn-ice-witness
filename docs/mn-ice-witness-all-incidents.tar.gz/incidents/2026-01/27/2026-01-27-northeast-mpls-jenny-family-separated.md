---
date: 2026-01-27
time: unknown
location: Parking lot, Northeast Minneapolis
city: Minneapolis
type: immigrants
status: ongoing
affected_individual_citizenship: undocumented
injuries: none
created: 2026-01-28T21:12:14
last_updated: 2026-01-28T21:12:14
search_tags: family-separation, children, src:wcco
---

# "I Was Yelling at Them to Take Me With Him": Mother Holds Daughter as Husband Detained in Northeast Minneapolis

## Summary
ICE agents detained a woman's husband and cousin in a parking lot in Northeast Minneapolis while she held her young daughter in the backseat. The woman, identified only as Jenny, pleaded with agents to deport her alongside her husband so the family could stay together, but was left behind with her child.

## Sources
1. CBS Minnesota Video (Jan 28, 2026): [Video shows ICE separating family during arrest in Minneapolis](https://www.cbsnews.com/minnesota/news/northeast-minneapolis-ice-arrest-video/)
2. Bluesky (Jan 27, 2026): [Aaron Rupar post with video](https://bsky.app/profile/atrupar.com/post/3mdgjohren22q)

## Affected Individual(s)
- **Name:** Jenny (last name withheld)
- **Citizenship:** Undocumented
- **Background:** From Ecuador. Her husband and cousin were detained; Jenny was left behind with her young daughter.

### Also Affected
- Jenny's husband — undocumented, from Ecuador, detained
- Jenny's cousin — undocumented, from Ecuador, detained

## Witness Accounts

> "I was yelling at them to take me with him, but they didn't want to take me and our daughter with him." — Jenny, CBS Minnesota
