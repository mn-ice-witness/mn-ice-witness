---
date: 2026-01-27
time: morning
location: Minneapolis preschool
city: Minneapolis
type: schools-hospitals
status: ongoing
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-28T08:28:50
last_updated: 2026-01-28T08:28:50
search_tags: children, chemical-agents, src:other-national
---

# ICE Agents Deploy Tear Gas Outside Minneapolis Preschool

## Summary

A video circulating on social media shows ICE agents deploying tear gas outside a Minneapolis preschool on the morning of January 27, 2026. Parents can be heard shouting "This is a preschool! There's kids here!"

**Possible location:** Community members have identified the preschool as [Whittier Wildflowers Preschool](https://whittierwildflowers.org), located at 2608 Blaisdell Ave S in the Whittier neighborhood of Minneapolis. This has not been confirmed by media sources.

## Sources

1. Bluesky (Jan 27, 2026): [Matt McDermott post with video](https://bsky.app/profile/mattmfm.bsky.social/post/3mdgdb5d5uk2n)
2. Chalkbeat (Jan 28, 2026): [Education groups say ICE immigration enforcement is hurting students](https://www.chalkbeat.org/2026/01/28/education-groups-say-ice-immigration-enforcement-is-hurting-students/) - cites "tear gas fired outside preschools"
3. Connecticut Attorney General (Jan 23, 2026): [Amicus brief supporting Minnesota challenge](https://portal.ct.gov/ag/press-releases/2026-press-releases/attorney-general-tong-supports-minnesota-challenge-to-militarized-and-illegal-deployments) - references tear gas and school impacts in Minneapolis
4. Massachusetts Attorney General (Jan 23, 2026): [Amicus brief](https://www.mass.gov/news/ag-campbell-challenges-militarized-and-illegal-deployments-of-federal-immigration-officers-in-minnesota) - references tear gas and school impacts in Minneapolis

## Affected Individual(s)

- **Names:** Not disclosed
- **Status:** Unknown

## What Happened

According to the Bluesky post, video from the morning of January 27 shows ICE agents deploying tear gas in an area outside a Minneapolis preschool. Parents at the scene can be heard protesting: "This is a preschool! There's kids here!"

The post received significant engagement but the specific preschool incident has not been independently verified by news outlets as of the time of documentation. Chalkbeat referenced "tear gas fired outside preschools" in a broader article about ICE enforcement impacts on education.
