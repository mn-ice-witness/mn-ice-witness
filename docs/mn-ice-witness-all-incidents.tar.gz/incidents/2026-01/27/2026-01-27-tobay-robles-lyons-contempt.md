---
date: 2026-01-27
time: evening
location: Federal District Court
city: Minneapolis
type: immigrants
status: resolved
affected_individual_citizenship: undocumented
injuries: none
created: 2026-01-27T08:47:47
last_updated: 2026-02-02T22:24:26
search_tags: src:nyt, src:nbc, src:wapo, src:cbs, src:abc, src:pbs, src:other-national, src:kare11, src:mn-reformer, src:sahan-journal, src:mpr
---

# Ecuadorean Man Held 3 Weeks Despite Court Order; Judge Orders ICE Director to Appear for Contempt

## Updates
- **Jan 28** - After his release in Texas, a supporter [drove from Minnesota to Texas](https://www.cnbc.com/2026/01/28/ice-immigrant-minnesota-contempt-released.html) to bring Tobay Robles home to reunite with his family and reestablish his interrupted medical care.
- **Jan 28** - Contempt hearing canceled after Tobay Robles' release. [Judge Schiltz documented](https://www.kare11.com/article/news/local/ice-in-minnesota/judge-ice-violated-nearly-100-court-orders-this-month/89-3e95803b-952f-4383-b09d-fc289cd9c21b) that ICE has violated **96 court orders in 74 cases** since January 1, 2026, stating "ICE is not a law unto itself" and "ICE has likely violated more court orders in January 2026 than some federal agencies have violated in their entire existence."
- **Jan 27** - [Tobay Robles released](https://www.mprnews.org/story/2026/01/27/judge-orders-ice-director-to-appear-federal-court-minneapolis) shortly after 1 p.m. following judge's contempt order against ICE director.

## Summary

Federal Judge Patrick Schiltz ordered ICE's acting director Todd Lyons to personally appear in court Friday to explain why he should not be held in contempt for violating court orders. The case stems from Juan Hugo Tobay Robles, an Ecuadorean man who entered the United States illegally in 1999 as a minor and has been in custody at Fort Snelling since January 6. Judge Schiltz ordered on January 14 that ICE allow Tobay Robles to challenge his detention at a hearing within a week or release him, finding ICE was holding him under an improper reading of federal law. ICE failed to comply. The judge, appointed by President George W. Bush, wrote that his "patience is at an end" and that while summoning the ICE director was "an extraordinary step," it was necessary because "the extent of ICE's violation of court orders is likewise extraordinary."

## Sources

1. New York Times (Jan 27, 2026): [Judge Orders ICE Chief to Appear in Court Over Potential Contempt](https://www.nytimes.com/2026/01/27/us/politics/ice-director-minnesota-contempt.html)
2. NBC News (Jan 27, 2026): [Judge threatens to hold acting ICE director in contempt for flouting court orders](https://www.nbcnews.com/politics/trump-administration/judge-threatens-hold-acting-ice-director-contempt-flouting-court-order-rcna256107)
3. Washington Post (Jan 27, 2026): [U.S. judge orders ICE chief to appear in court, threatens contempt ruling](https://www.washingtonpost.com/national-security/2026/01/27/ice-federal-judge-contempt/)
4. CBS News (Jan 27, 2026): [Judge in Minnesota orders ICE chief to appear in court, warns of possible contempt proceedings](https://www.cbsnews.com/news/ice-minnesota-judge-contempt/)
5. ABC News (Jan 27, 2026): [Acting ICE director must appear in court in person, judge rules](https://abcnews.go.com/US/live-updates/minneapolis-ice-shooting-live-updates-doj-investigating-apparent?id=129340693)
6. PBS News (Jan 27, 2026): [ICE chief ordered to appear in court to explain why detainees have been denied due process](https://www.pbs.org/newshour/politics/ice-chief-ordered-to-appear-in-court-to-explain-why-detainees-have-been-denied-due-process)
7. NewsNation (Jan 27, 2026): [Todd Lyons, ICE chief, summoned by Minnesota judge, faces contempt](https://www.newsnationnow.com/us-news/immigration/border-coverage/minnesota-judge-todd-lyons-contempt-hearing/)
8. Philadelphia Inquirer (Jan 27, 2026): [ICE chief must appear in court to explain why detainees have been denied due process](https://www.inquirer.com/news/nation-world/ice-immigration-enforcement-minnesota-due-process-20260127.html)
9. KARE 11 (Jan 28, 2026): [Judge says ICE has violated nearly 100 court orders this month](https://www.kare11.com/article/news/local/ice-in-minnesota/judge-ice-violated-nearly-100-court-orders-this-month/89-3e95803b-952f-4383-b09d-fc289cd9c21b)
10. CNBC (Jan 28, 2026): ['ICE is not a law unto itself,' Minnesota judge says](https://www.cnbc.com/2026/01/28/ice-immigrant-minnesota-contempt-released.html)
11. Sahan Journal (Jan 2026): [Judge demands head of ICE appear at Minnesota court hearing](https://sahanjournal.com/immigration/judge-orders-ice-leader-todd-lyons-appear-court-minnesota/)
12. Minnesota Reformer (Jan 27, 2026): [ICE releases detainee following slapdown from federal judge](https://minnesotareformer.com/2026/01/27/ice-releases-detainee-following-slapdown-from-federal-judge/)
13. MPR News (Jan 27, 2026): [Judge orders ICE director to appear in federal court in Minneapolis](https://www.mprnews.org/story/2026/01/27/judge-orders-ice-director-to-appear-federal-court-minneapolis)

## Affected Individual(s)

- **Name:** Juan Hugo Tobay Robles
- **Citizenship:** Ecuadorean, entered U.S. illegally in 1999 as a minor
- **Detention Location:** Fort Snelling, Minnesota
- **Status:** Released January 28, 2026 in Texas; had been in custody since January 6

## Timeline

- **Jan 6** - Tobay Robles detained by immigration agents.
- **Jan 14** - Judge Schiltz orders ICE to allow Tobay Robles to challenge detention at a hearing within one week, or release him; determines ICE is holding him under improper reading of federal law.
- **Jan 27 (evening)** - Judge Schiltz issues ruling summoning ICE Acting Director Todd Lyons to appear in court Friday to explain why he should not be held in contempt.
- **Jan 28** - Tobay Robles released from detention in Texas.
- **Jan 28** - Contempt hearing canceled following release.
- **Jan 28** - Supporter drove from Minnesota to Texas to bring Tobay Robles home.

## Court Order Details

Judge Schiltz wrote that he had been "extremely patient" with ICE even though the agency had sent thousands of agents to Minnesota as part of President Trump's immigration crackdown without preparing for the legal challenges that "were sure to result."

The judge's order noted this case is "one of dozens of court orders with which respondents have failed to comply in recent weeks." He wrote that the consequence of ICE's failures "has almost always been significant hardship to aliens (many of whom have lawfully lived and worked in the United States for years and done absolutely nothing wrong.)"

## Context

Judge Schiltz, who clerked for Justice Antonin Scalia, has emerged as an unlikely critic of the administration. Last Friday, he rejected a Justice Department request to reverse another judge's decision and issue arrest warrants for journalist Don Lemon and four others connected to a church protest in St. Paul, calling the department's request "frivolous" and "unprecedented."
