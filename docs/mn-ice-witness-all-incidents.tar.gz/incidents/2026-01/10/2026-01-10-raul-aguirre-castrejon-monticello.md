---
date: 2026-01-10
time: unknown
location: Monticello, near Walmart
city: Monticello
type: citizens
status: resolved
affected_individual_citizenship: legal-resident
injuries: minor
created: 2026-02-07T14:12:42
last_updated: 2026-02-07T14:12:42
search_tags: legal-resident, excessive-force, citizen-check, shooting, vehicle-pursuit, warrantless-entry
---

# Legal Permanent Resident Boxed In on Road, Handcuffed at Gunpoint; Agents Take Cash from Wallet

## Summary
Raul Aguirre Castrejon, a lawful permanent resident, was followed by two SUVs after leaving a Walmart in Monticello with his niece, a U.S. citizen. Agents boxed them in on the road, pulled Castrejon from the car, handcuffed him, pointed weapons at him, and took $130 in cash from his wallet. Despite carrying proof of legal status, agents told him "you're not from here." He was released after a few minutes and later filed a sworn declaration in the ACLU's **Hussen v. Noem** lawsuit.

## Sources
1. Court Filing (Jan 16, 2026): [Declaration of Raul Aguirre Castrejon, Hussen v. Noem Case 26-cv-00324](https://www.justsecurity.org/pdfs/mn-ice-enforcement/14%20RAUL%20AGUIRRE%20CASTREJON.pdf)
2. Substack (Jan 31, 2026): [Operation Metro Surge in the Court](https://ashtalks.substack.com/p/operation-metro-surge-in-the-court)


## Affected Individual(s)
- **Name:** Raul Aguirre Castrejon
- **Status:** Lawful permanent resident since 2025
- **Medical:** Back surgery seven months prior; handcuffing aggravated recovery
- **Injuries:** Scrapes from handcuffs, aggravated back condition

### Niece (driver)
- **Citizenship:** U.S. citizen
- **Role:** Was driving; became "crying and nearly hysterical"

## Timeline
- **Unknown time** - Castrejon and his niece leave Walmart in Monticello after getting groceries.
- **Followed** - Two SUVs (black Cherokee and white SUV with Florida plates) follow them, matching lane changes.
- **Boxed in** - Black Cherokee pulls ahead to box them in. When they try to exit the road, the Cherokee nearly runs them off it, swerving in front. Niece brakes hard to avoid collision.
- **Pulled from car** - Agents demand they exit. They pull down the window, open the door, and drag Castrejon out. Five to six men handcuff him and try to push him into the Cherokee.
- **Keys taken** - Another agent reaches into the car, turns off the engine, and takes the keys.
- **Proof ignored** - Castrejon repeatedly yells he is legal. An officer responds: "You're not from here. Where are you from?"
- **Recording stopped** - Agents grab his wallet and phone, turn off the phone to stop his recording.
- **Weapons pointed** - Agents point weapons at him and yell at him to shut up. Handcuffs are very tight, aggravating his recent back surgery.
- **Released** - After a few minutes, someone tells the agents to let him go.
- **Money taken** - Wallet originally contained $235 ($100, 2×$50, $20, $10, $5). Agents kept $130 (the two $50s, $20, $10). Also took his insurance policy card.
- **Excuse given** - Agents said they stopped the car because it was being driven by a woman but registered to a man.

## Affected Individual Statement

### Raul Aguirre Castrejon
> "I kept yelling that I was legal."

> "Even though I am a lawful permanent resident and I was carrying proof of that with me, ICE agents still used force against me and arrested me."

## Constitutional Concerns
- No warrant presented
- Dangerous vehicle pursuit and boxing-in maneuver on public road
- Proof of legal residency ignored
- Phone seized and recording stopped
- Cash and insurance card taken from wallet and not returned
- Weapons pointed during stop
- Pretext for stop (registered owner vs. driver gender) used to justify racial profiling

## Legal Action
Raul Aguirre Castrejon filed a sworn declaration as part of **Hussen v. Noem** (Case 26-cv-00324-ECT-ECW), the ACLU class-action lawsuit alleging racial profiling by ICE/CBP agents during Operation Metro Surge.
