---
date: 2026-01-10
time: evening
location: Walmart, Maple Grove
city: Maple Grove
type: immigrants
status: under-investigation
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-14T08:01:12
last_updated: 2026-01-14T08:01:12
search_tags: src:bring-me-the-news
---

# Man Pinned and Arrested Inside Maple Grove Walmart

## Summary
Six ICE agents arrested a man inside a Walmart in Maple Grove on Saturday night. Video shows agents pinning the individual to the ground inside the store before handcuffing him, escorting him out, and placing him in a red SUV.

## Sources
1. Bring Me The News (Jan 11, 2026): [Video shows ICE agents pinning man inside Maple Grove Walmart](https://bringmethenews.com/minnesota-news/video-shows-ice-agents-pinning-man-inside-maple-grove-walmart)
2. Bring Me The News (Jan 9, 2026): [Pattern emerging of ICE targeting civilians at Twin Cities retail stores](https://bringmethenews.com/minnesota-news/pattern-emerging-of-ice-targeting-civilians-at-twin-cities-retail-stores)

## Affected Individual(s)
- **Name:** Unknown
- **Citizenship:** Unknown
- **Details:** Shopping at Walmart when arrested

## Timeline
- **Saturday evening** - Man shopping at Maple Grove Walmart
- **Arrest** - Six ICE agents approach and pin man to the ground
- **Handcuffing** - Man cuffed while on floor inside store
- **Transport** - Escorted out and placed in back of red, mid-size SUV

## Witness Accounts
During the incident inside, a bystander had a back-and-forth with an ICE agent. Video was shared on social media.

## Context
Part of broader pattern of ICE operations at Twin Cities retail locations. Videos have circulated of agents making arrests inside Walmart stores in the Twin Cities area.
