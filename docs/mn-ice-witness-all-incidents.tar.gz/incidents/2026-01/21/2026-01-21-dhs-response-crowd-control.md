---
date: 2026-01-21
time: unknown
location: DHS Official Statement
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-21T21:54:31
last_updated: 2026-01-21T21:54:31
search_tags: chemical-agents, src:fox-news, src:other-national
---

# DHS Response: Agents "Harassed" at Gas Stations, Used "Crowd Control Measures"

## Summary

DHS posted on X claiming Border Patrol agents were "repeatedly harassed and blocked by hostile crowds" while taking bathroom breaks at gas stations in Minneapolis-St. Paul. DHS states someone spit on an agent, the crowd "tackled and attacked the agents," and agents "had to use crowd control measures to disperse the hostile crowd."

## Sources

1. X Post (Jan 21, 2026): [@DHSgov statement](https://x.com/DHSgov/status/2014137749125693840)
2. Fox News (Jan 22, 2026): [Minnesota agitators stalk, pelt Border Patrol agents with food and spit at gas stations, DHS says](https://www.foxnews.com/us/minnesota-agitators-stalk-pelt-border-patrol-agents-food-spit-gas-stations-dhs-says)
3. Instagram Video (Jan 21, 2026): [Gas station confrontation footage](https://www.instagram.com/reels/DTyrnFdkRSK/)
4. Facebook Video (Jan 21, 2026): [Gas station confrontation footage](https://www.facebook.com/reel/1439489157581713/)
5. Mediaite (Jan 21, 2026): [DHS Says Protesters Won't Let Immigration Agents Pee in Peace](https://www.mediaite.com/media/news/dhs-says-protesters-wont-let-immigration-agents-pee-in-peace-simply-trying-to-take-bathroom-breaks/)
6. New Republic (Jan 21, 2026): [CBP chief confronted at Minnesota gas station](https://newrepublic.com/post/205524/customs-border-protection-cbp-bovino-minnesota-gas-station)

## Related Incidents

- [Observer Pinned to Ground, Chemical Irritant Sprayed Directly Into Face](#2026-01-21-observer-pinned-pepper-sprayed-face)
- [Border Patrol Commander Greg Bovino Deploys Smoke Canister Near School at Dismissal](#2026-01-21-bovino-smoke-canister-playground)

## Official Statement

Posted on X (@DHSgov):

> "Today, Border Patrol agents who were in the Minneapolis–St. Paul area as part of a targeted enforcement operation were repeatedly harassed and blocked by hostile crowds while simply trying to take bathroom breaks.
>
> At each gas station where the agents stopped to use the restroom, groups of agitators appeared, yelled at them, stalked them, and even tried to prevent law enforcement vehicles from leaving, creating unsafe conditions. At one stop, individuals in the crowd threw food at the agents. At their final gas station stop, someone spit on an agent. When an agent moved to detain the person who spit on him, the crowed tackled and attacked the agents while surrounding them.
>
> To safely clear the area agents had to use crowd control measures to disperse the hostile crowd."

## Context

This statement was posted after videos circulated showing Border Patrol Commander Greg Bovino deploying a smoke canister at Mueller Park near Ella Baker Global Studies & Humanities Magnet School during school dismissal, and agents pinning an observer to the ground and spraying chemical irritant directly into his face.

The incident occurred four days after U.S. District Judge Katherine Menendez issued a preliminary injunction barring federal agents from using pepper spray on peaceful protesters and observers.
