---
date: 2026-01-21
time: unknown
location: Residential street
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-02-14T21:59:38
last_updated: 2026-02-14T21:59:38
search_tags: us-citizen, observer-intimidated, src:nyt, src:other-national
---

# ICE Vehicles Stop at Observer's Home; Agent Photographs House While Another Holds AR-15

## Summary
Katie Henly, 40, a project manager in local government, went out on January 21 to monitor suspected ICE agents. She identified two vehicles, texted their plates to her monitoring group to confirm they were federal, and began following them. The vehicles turned onto her street and stopped at her house, where an agent poked a camera out the SUV window and photographed her home. Henly continued following the SUV to a stop sign, where four agents exited; one held a camera and another carried an AR-15-style rifle. Henly filed a sworn declaration in Tincher v. Noem.

## Sources
1. New York Times (Feb 13, 2026): [ICE Agents Menaced Minnesota Protesters at Their Homes, Filings Say](https://www.nytimes.com/2026/02/13/us/minneapolis-ice-agents-protester-home-visits.html)
2. Spokesman-Review (Feb 14, 2026): [ICE Agents Menaced Minnesota Protesters at Their Homes, Filings Say](https://www.spokesman.com/stories/2026/feb/14/ice-agents-menaced-minnesota-protesters-at-their-h/) *(NYT syndication)*
3. ACLU-MN (Feb 13, 2026): [New Filings Detail Harrowing Accounts of ICE and Border Patrol Violence](https://www.aclu.org/press-releases/new-filings-detail-harrowing-accounts-of-ice-and-border-patrol-violence-and-intimidation-against-minnesotans)

## Affected Individual(s)

### Katie Henly
- **Age:** 40
- **Occupation:** Project manager, local government
- **Citizenship:** U.S. citizen

## Affected Individual Statement

> "I was more scared of that camera than I was of that gun. The gun goes away. The camera is capturing me, and the unknown of what is happening with my image is scarier to me."

> "I'm not trying to stop an investigation from happening. That is not my purpose. My purpose when I went out there that day was to have eyes on the street in case something did happen."

## Related Incidents
- [ACLU Sues to Protect Observers: Tincher v. Noem](#2025-12-17-tincher-v-noem-aclu-lawsuit) — Henly filed sworn declaration
- [ICE Agents Follow Observers Home](#2026-01-06-levy-observers-followed-home) — Same pattern of following observers to residences
