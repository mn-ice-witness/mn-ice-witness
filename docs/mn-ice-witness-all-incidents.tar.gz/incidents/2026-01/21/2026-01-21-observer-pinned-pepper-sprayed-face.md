---
date: 2026-01-21
time: afternoon
location: 28th Street and Blaisdell Avenue S.
city: Minneapolis
type: observers
status: ongoing
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-21T18:01:29
last_updated: 2026-01-21T18:01:29
search_tags: observer-intimidated, observer-detained, excessive-force, chemical-agents, src:star-tribune, src:nyt
---

# Observer Pinned to Ground, Chemical Irritant Sprayed Directly Into Face

## Summary

Federal agents pinned an observer to the ground and sprayed a chemical irritant directly into his face at 28th Street and Blaisdell Avenue S. in south Minneapolis. A Star Tribune photographer captured the moment of the spray being deployed at point-blank range while multiple agents held the man down.

## Sources

1. Star Tribune Photo (Jan 21, 2026): [ICE raids Minnesota live updates](https://www.startribune.com/ice-raids-minnesota/601546426) - Photo by Richard Tsong-Taatarii
2. Reddit (Jan 21, 2026): [r/FedEmployees post with photo](https://www.reddit.com/r/FedEmployees/comments/1qjdnhw/observer_being_arrested_and_pepper_sprayed_at/)
3. Threads (Jan 21, 2026): [@msbellaf post](https://www.threads.com/@msbellaf/post/DTyf2oUFQ52)
4. New York Times (Jan 23, 2026): [Pepper-Sprayed While Pinned Down: A Searing Scene Provokes Outrage](https://www.nytimes.com/2026/01/23/us/minneapolis-man-pepper-sprayed-pinned-video.html)

## Affected Individual(s)

- **Name:** Unknown
- **Status:** Pinned to ground by multiple agents, pepper sprayed directly in face

## Context: Federal Injunction on Chemical Irritants

On January 16, 2026, U.S. District Judge Katherine Menendez issued a preliminary injunction barring federal agents participating in Operation Metro Surge from using pepper spray on peaceful protesters and observers. The court found that chemical agents had been used against protesters on at least four separate occasions and that "protected conduct—including peaceful protesting and observation—had motivated the agents' actions."

This incident occurred five days after that injunction was issued.

## Related Incidents

- [DHS Response: Agents "Harassed" at Gas Stations, Used "Crowd Control Measures"](#2026-01-21-dhs-response-crowd-control) (Jan 21)
- [DHS Secretary Noem Denies Pepper Spray Use, Then Backtracks](#2026-01-18-noem-pepper-spray-denial-backtrack) (Jan 18)
- [Two ICE Observers Pepper-Sprayed in Car, Detained 8 Hours](#2026-01-11-siguenza-okeefe-detained) (Jan 11)
