---
date: 2026-01-22
time: afternoon
location: Welcome Avenue, Brooklyn Park (near Aldi)
city: Brooklyn Park
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-23T20:07:14
last_updated: 2026-01-23T20:07:14
search_tags: us-citizen, observer-detained, src:kare11, src:star-tribune, src:mpr, src:fox9, src:nbc
---

# Two Detained Women Become First Responders After ICE Agent Has Seizure

## Summary
Tippy Amundson (39) and Heather Zemien (55), both U.S. citizens, were detained by ICE in Brooklyn Park. While being transported to Whipple Federal Building, an ICE agent had a seizure. The women recognized the emergency when the agents did not, directed them to call 911, and provided first aid after being uncuffed. Despite saving the agent's life, they were still taken to Whipple. Upon release, a commanding officer told them: "You need to tell everybody that we treated you kindly."

## Sources
1. KARE 11 Video (Jan 23, 2026): [Woman detained after helping ICE agent](https://www.youtube.com/watch?v=atY_aW3isYk)
2. Star Tribune (Jan 23, 2026): [Detained by ICE, two women became first responders during agent's seizure](https://www.startribune.com/detained-by-ice-two-women-became-first-responders-during-agents-seizure/601569667)
3. MPR News (Feb 3, 2026): [Brooklyn Park women help seizing ICE agent while detained](https://www.mprnews.org/story/2026/02/03/brooklyn-park-women-help-seizing-ice-agent-while-detained)
4. FOX 9 (Jan 27, 2026): [Woman saves ICE agent during medical emergency after being detained](https://www.fox9.com/news/woman-saves-ice-agent-during-medical-emergency-after-being-detained-jan-2026)
5. NBC News Video (Feb 3, 2026): [Two women in ICE custody save the federal agent who detained them](https://www.nbcnews.com/now/video/two-women-in-ice-custody-save-the-federal-agent-who-detained-them-256652357896)

## Affected Individual(s)
- **Tippy Amundson:** 39, U.S. citizen, kindergarten teacher with CPR and first-aid training
- **Heather Zemien:** 55, U.S. citizen, personal care attendant

## Timeline
- Detained in Brooklyn Park on afternoon of Jan 22
- While being transported to Whipple, ICE agent in third row had a seizure
- Amundson and Zemien recognized the emergency, directed other agents to pull over and call 911
- Women were uncuffed and provided first aid (positioning agent on his side, supporting his head, keeping airway open) until EMS arrived
- Despite saving the agent's life, they were still transported to Whipple Federal Building
- Upon release, a commanding officer told them: "You need to tell everybody that we treated you kindly"

## Reason for Detention
Both women were advised by attorneys not to discuss why they were being held

## Notable Details
- Amundson reflected: "I was hit so hard with the fact that this man would not do this for me"
- Her mind went immediately to Renee Good
- ICE did not respond to requests for information about the incident or questions about its medical and safety protocols
