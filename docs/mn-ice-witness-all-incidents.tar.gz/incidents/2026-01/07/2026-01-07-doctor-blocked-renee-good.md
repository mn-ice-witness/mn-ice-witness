---
date: 2026-01-07
time: morning
location: 34th Street, Powderhorn Park area
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-17T23:35:39
last_updated: 2026-01-20T22:44:32
search_tags: us-citizen, observer-intimidated, shooting, src:mpr, src:star-tribune, src:cnn, src:kare11, src:other-local, src:other-national
---

# ICE Blocks Physician From Helping Shooting Victim

## Updates
- **Jan 20:** Credible evidence emerges that Good was alive for 8 minutes after being shot.

## Summary
After ICE agent Jonathan Ross shot Renee Good, a bystander who identified himself as a physician attempted to provide medical assistance. ICE agents refused to let him near the affected individual. When the bystander said "I'm a physician," an agent replied "I don't care." Agents claimed they had their own medics on the way, but witness Emily Heller reported it was at least 15 minutes before an ambulance arrived. ICE vehicles abandoned at the scene blocked the ambulance's access.

## Sources
1. The Hill (Jan 8, 2026): ['Can I check a pulse?': Video shows ICE preventing doctor from tending to Minneapolis shooting victim](https://thehill.com/homenews/state-watch/5679332-video-ice-minneapolis-shooting-renee-nicole-good/)
2. Wikipedia (Jan 15, 2026): [Killing of Renee Good](https://en.wikipedia.org/wiki/Killing_of_Renee_Good)
3. WION News (Jan 15, 2026): ["You killed my fu**ing neighbour": Medic begs to help Renee Good, ICE officer tells him "I don't care"](https://www.wionews.com/trending/-you-killed-my-fu-ing-neighbour-medic-begs-to-help-renee-good-ice-officers-tells-him-i-don-t-care-disturbing-video-emerges-1767857999720)
4. HuffPost (Jan 15, 2026): [A Doctor Was Blocked From Helping An ICE Shooting Victim — Is That Even Allowed?](https://www.huffpost.com/entry/a-doctor-was-blocked-from-helping-an-ice-shooting-victim-is-that-even-allowed-goog_l_6969313ae4b00edae2a4036f)
5. Border Report (Jan 15, 2026): ['Can I check a pulse?': Video shows agents preventing doctor from tending to Minneapolis shooting victim](https://www.borderreport.com/hot-topics/can-i-check-a-pulse-video-shows-agents-preventing-doctor-from-tending-to-minneapolis-shooting-victim/)
6. MPR News (Jan 17, 2026): [ICE agents are trained in CPR. They didn't use it on Renee Macklin Good](https://www.mprnews.org/story/2026/01/17/ice-agents-are-trained-in-cpr-they-didnt-use-it-on-renee-macklin-good)
7. Star Tribune (Jan 15, 2026): [Should ICE agents have refused bystander medical help at shooting scene?](https://www.startribune.com/should-ice-agents-have-refused-bystander-medical-help-at-shooting-scene/601560462)
8. BP Daily (Jan 15, 2026): ["I Don't Care": Video Shows ICE Agent Rejecting Doctor's Help For Shooting Victim Renee Good](https://www.bpdaily.com/ice-agent-dont-care-medical-help-renee-good/)
9. Threads (Jan 15, 2026): [Post about doctor blocked from helping Renee Good](https://www.threads.com/@aaronparnas/post/DTwVrTvkoXQ)
10. CNN (Jan 16, 2026): [911 transcripts and incident report reveal where Minneapolis mother was shot](https://www.cnn.com/2026/01/16/us/renee-good-shooting-incident-report)
11. APM Reports (Jan 17, 2026): [ICE agents didn't use CPR after Jonathan Ross shot Renee Macklin Good](https://www.apmreports.org/story/2026/01/17/ice-agents-didnt-use-cpr-after-jonathan-ross-shot-renee-macklin-good-in-minneapolis)
12. KARE 11 (Jan 8, 2026): [Man claiming to be physician denied ability to check on Renee Good after shooting](https://www.kare11.com/article/news/local/ice-in-minnesota/watch-man-claiming-to-be-physician-denied-ability-to-check-on-renee-good-shooting/89-47b9c154-b278-49dd-9560-33cc1a8ae751)
13. IBTimes (Jan 15, 2026): [Renee Good Was Still Alive When ICE Blocked Aid With an 'I Don't Care' Response](https://www.ibtimes.com/renee-good-was-still-alive-when-ice-blocked-aid-i-dont-care-response-3795730)
14. WBAL TV (Jan 15, 2026): [911 transcripts, incident report details fatal ICE shooting of Renee Good](https://www.wbaltv.com/article/minneapolis-ice-shooting-renee-good/70020427)
15. Facebook Video (Jan 7, 2026): [ICE blocks doctor from helping Renee Good](https://www.facebook.com/reel/1613959399783824)

## Affected Individual(s)
- **Name:** Unidentified physician (bystander)
- **Citizenship:** Unknown (U.S. citizen implied)
- **Role:** Attempted to provide emergency medical care

## The Exchange (from video)
- **Physician:** "Can I go check a pulse?"
- **Agent 1:** "No! Back up! Now!"
- **Physician:** "I'm a physician!"
- **Agent 1:** "I don't care."
- **Agent 2:** "Listen, we understand, we got EMS coming, alright?"
- **Agent (unclear which):** "We have medics on scene, we have our own medics."
- **Bystander:** "WHERE ARE THEY?"
- **Agent:** "Relax."
- **Bystander:** "How can I relax you just killed my fucking neighbor! You shot her in the fucking face! You killed my fucking neighbor! How do you show up to work every day?"

## Witness Account

**Emily Heller (recorded the video):**
> "Yeah, they wouldn't let him near. And they said they had their own medics that were on their way, which it was — it was, I mean, I don't know, it was at least 15 minutes before the ambulance arrived."

Heller told CNN the ambulance couldn't get through because vehicles "abandoned" by the ICE agents on scene were blocking the road.

## Medical Response Failures
- There is credible evidence that Good was alive for 8 minutes after being shot.
- Agents waited 3 minutes to call 911 after the shooting.
- After brief medical assessment, agents left Good bleeding in her car.
- When emergency responders arrived, Good was "unresponsive, not breathing, with inconsistent, irregular, thready pulse activity."
- ICE agents are trained in CPR but did not perform it on Good.

## Legal Analysis

**Alexa Van Brunt (MacArthur Justice Center):**
> "What is so disturbing about that scene is that they were denying access to somebody who was a physician, so [someone] who obviously had at least suggested that they had the qualifications and the ability to help in an emergency, while not seemingly providing any medical care themselves. It really seems unlawful, a violation of law, I'm sure a violation of ICE standards and training."

**Professor Ayesha Bell Hardaway:**
> "The failure of the agents to follow stated policy is one that should not be overlooked. Minneapolis and many other jurisdictions have revised their police policies to include a duty to render aid immediately after a use of deadly force incident."

## Context
This refusal to allow bystander medical assistance echoes the restraint-related death of George Floyd, where bystander offers to help were also denied.
