---
date: 2026-01-15
time: 13:00
location: 2928 Apartment, South Minneapolis
city: Minneapolis
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-16T16:02:47
last_updated: 2026-01-16T16:02:47
search_tags: us-citizen, excessive-force, warrantless-entry, src:wcco, src:other-national
---

# Federal Agents Execute Search Warrant at Wrong Address; U.S. Citizen Mistakenly Arrested

## Summary
FBI, ATF, and Hennepin County Sheriff's Office agents used a battering ram to enter Alisa Porter's South Minneapolis apartment, handcuffing her daughter and searching the home. The warrant was for a different address—the man they sought had lived in the unit above Porter's but moved out two months prior. The search was connected to items stolen from FBI vehicles.

## Sources
1. CBS Minnesota (Jan 15, 2026): [Minneapolis family says federal agents raided wrong apartment looking for items stolen from FBI vehicles](https://www.cbsnews.com/minnesota/news/minneapolis-fbi-raid-wrong-home/)
2. The Mirror (Jan 16, 2026): [ICE ransack Minneapolis woman's home after 'conducting search warrant in wrong home'](https://www.themirror.com/news/us-news/ice-ransack-minneapolis-womans-home-1623040)
3. YouTube Video (Jan 15, 2026): [CBS Minnesota report](https://www.youtube.com/watch?v=_mulYNgbs14)

## Affected Individual(s)
- **Name:** Alisa Porter and daughter
- **Citizenship:** U.S. Citizens
- **Background:** Porter was at a doctor's appointment when neighbors called to inform her that federal agents had handcuffed her daughter and were searching her home.

## Timeline
- **~13:00** - Federal agents arrive at apartment building
- **Shortly after** - Agents use battering ram to breach door; Ring camera captures agents with long guns entering
- **During raid** - Porter's daughter handcuffed; apartment searched; Ring camera torn from wall
- **After raid** - Door left damaged, unable to close; agents leave behind copy of warrant showing wrong address (2926 vs Porter's 2928 Apt 2)
- **Thursday night** - Federal investigators announce suspect taken into custody elsewhere

## Official Accounts

### Federal Agencies
An ATF spokesperson declined to comment due to the "ongoing nature of this operation" but confirmed the agency executed a search warrant in Minneapolis.

The operation involved multiple agencies: FBI, ATF, and Hennepin County Sheriff's Office. The Hennepin County Sheriff's Office stated they were conducting a criminal investigation and executing multiple search warrants for items stolen from federal vehicles on Wednesday night, including a firearm, multiple FBI access badges, wallets, driver's licenses, and credit cards.

### Local Officials
No statements from local officials documented.

## Witness Accounts
Alisa Porter: "This is not the place you're supposed to be at looking for anything."

Porter stated her daughter "was scared to death" when agents handcuffed her during the search. Porter also confirmed the man named on the warrant had lived in the unit above hers but moved out two months ago.

A neighbor called Porter during the search to inform her what was happening.

## Context
This search occurred during a period of heightened federal law enforcement activity in Minneapolis related to Operation Metro Surge. The items were stolen from FBI vehicles that were broken into the previous night. This was not an immigration enforcement action but is included to document the broader federal enforcement presence affecting Minneapolis residents.
