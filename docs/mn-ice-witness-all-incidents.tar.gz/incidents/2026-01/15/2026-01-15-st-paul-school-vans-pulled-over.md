---
date: 2026-01-15
time: morning
location: En route to schools
city: St. Paul
type: schools-hospitals
status: resolved
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-16T09:20:36
last_updated: 2026-01-16T09:20:36
search_tags: children, src:fox9, src:mpr, src:wcco
---

# Two St. Paul School Vans Pulled Over by ICE With Students and Teachers Aboard

## Summary
Federal ICE agents pulled over two St. Paul Public Schools contract vans while students and staff were on board during the week of January 13-15, 2026. Staff followed district protocols by keeping doors closed and communicating through windows. Both vans were allowed to continue to school without further disruption. The district subsequently announced temporary virtual learning starting January 22.

## Sources
1. FOX 9 (Jan 15, 2026): [St. Paul Schools van full of teachers, students pulled over by ICE agents](https://www.fox9.com/news/st-paul-schools-van-pulled-over-ice-agents-jan-2026)
2. MPR News (Jan 15, 2026): [Two St. Paul school vans were pulled over by federal agents](https://www.mprnews.org/story/2026/01/15/ice-shooting-minneapolis-minnesota-latest-updates)
3. KSTP (Jan 15, 2026): [Several school districts offering online learning in response to ICE activity](https://kstp.com/inside-your-schools/several-school-districts-offering-online-learning-in-response-to-ice-activity/)

## Affected Individual(s)
- **Affected:** Students and teachers aboard two contract school vans
- **Number:** Multiple students and staff members (exact count not disclosed)
- **Citizenship:** Students are minors; citizenship status not relevant to incident

## Timeline
- **Week of Jan 13-15** - Two SPPS contract vans are pulled over by federal ICE agents
- **First stop** - ICE agents approach van; staff keep doors closed per protocol
- **Both incidents** - Staff communicate through windows, follow district protocols
- **Resolution** - Both vans allowed to continue to school without further disruption
- **Jan 15** - SPPS confirms incidents, announces virtual learning option.
- **Jan 22** - Virtual learning begins for families who opt in.

## District Response

### Superintendent Statement
SPPS officials confirmed the incidents and emphasized that staff followed established protocols:
- Drivers kept vehicle doors closed during ICE approaches.
- Staff communicated only through windows.
- Managers were contacted for guidance on legal compliance.

### Safety Measures
- SPPS announced temporary virtual learning starting January 22, 2026
- Classes canceled January 20-21
- Registration for virtual learning opened January 15

### District Protocols
The district has trained bus drivers to:
- Not allow unauthorized people onto buses.
- Keep doors closed during approaches by unknown individuals.
- Contact managers for guidance.

## Official Accounts

### School District
SPPS spokesperson Erica Wacker confirmed the incidents occurred on Monday (Jan 13) and Wednesday (Jan 15).

### District Position on Data
SPPS does not keep information about families' immigration status and follows state and federal laws on data sharing.

## Context
This incident is part of broader ICE enforcement activity affecting Minnesota schools:
- Minneapolis Public Schools canceled classes district-wide earlier in January.
- Multiple districts have offered remote learning options.
- Parent was detained at Crystal bus stop the day before (Jan 14).
