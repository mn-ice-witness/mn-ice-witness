---
date: 2026-01-15
time: "10:30"
location: VINE Faith in Action, Mankato
city: Mankato
type: immigrants
status: ongoing
affected_individual_citizenship: unknown
injuries: none
created: 2026-02-02T20:32:49
last_updated: 2026-02-02T20:40:51
search_tags: workplace-raid, src:other-local
---

# Two Subcontractors Detained at VINE Faith in Action Senior Center

## Summary
Two construction subcontractors were detained by ICE agents while working on exterior repairs at VINE Faith in Action, a senior services facility in Mankato. One worker was apprehended in the parking lot; the second was detained on the opposite side of the building. The incident occurred in front of elderly members and staff.

## Sources
1. Mankato Free Press (Jan 15, 2026): [Two subcontractors at VINE detained](https://www.mankatofreepress.com/news/local_news/two-subcontractors-at-vine-detained/article_39cdf457-e46c-47e1-be11-7dcafe98cd80.html)
2. KEYC (Jan 16, 2026): [ICE activity ramps up in Mankato](https://www.keyc.com/2026/01/16/ice-activity-ramps-up-mankato/)

## What Happened
- Two subcontractors were working on exterior EIFS (Exterior Insulation and Finish System) repairs during a renovation project
- ICE agents detained both workers at approximately 10:30 a.m.
- One was apprehended in the parking lot and handcuffed
- The second moved to the opposite side of the building but was subsequently detained

## Witness Account
VINE CEO Melinda Wedzina witnessed the incident and described the impact on elderly members present: "Members had reactions from tears, sadness and concern. Some go into a mode of protection."

## Context
VINE Faith in Action serves seniors in the Mankato area. The detention occurred in full view of staff and elderly members during routine renovation work.
