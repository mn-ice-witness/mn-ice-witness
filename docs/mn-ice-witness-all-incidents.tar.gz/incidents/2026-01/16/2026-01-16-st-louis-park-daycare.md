---
date: 2026-01-16
time: 09:00
location: Daycare parking lot
city: St. Louis Park
type: schools-hospitals
status: resolved
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-17T11:14:22
last_updated: 2026-01-17T11:14:22
search_tags: children, observer-intimidated, src:bring-me-the-news, src:other-national
---

# ICE Agents Near St. Louis Park Daycare Threaten Parent with Pepper Spray

## Summary
Two unmarked ICE vehicles were parked directly across from a St. Louis Park daycare parking lot and playground as parents were dropping off children around 9 a.m. When a parent confronted the masked agents, they threatened him with pepper spray. St. Louis Park police responded and the agents left the area.

## Sources
1. Bring Me The News (Jan 16, 2026): [ICE agents waiting near St. Louis Park daycare confronted by parent](https://bringmethenews.com/minnesota-news/ice-agents-waiting-outside-st-louis-park-daycare-confronted-by-parent)
2. Yahoo News (Jan 16, 2026): [ICE agents waiting near St. Louis Park daycare confronted by parent](https://www.yahoo.com/news/articles/ice-agents-waiting-near-st-205706448.html)

## Witness Account
A source, speaking on condition of anonymity to protect the privacy of the daycare, said: "They threatened to mace him, but shortly after St. Louis Park police arrived, and they left the immediate area."

## Official Response

### St. Louis Park Police Department
A spokesperson confirmed officers were called to a report of a suspicious vehicle at around 9:30 a.m.

## Context
This incident occurred amid rising concerns about ICE presence near schools and daycares in Minnesota. Earlier in the week, KARE 11 reported that multiple employees from two Spanish immersion daycares in the Twin Cities were taken into custody by ICE, including one who was detained in the daycare parking lot. In both cases, the centers said the workers were legally authorized to work in the United States.
