---
date: 2026-01-13
time: unknown
location: East Lake Street
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-18T00:00:00
last_updated: 2026-01-18T00:00:00
search_tags: observer-detained, us-citizen, excessive-force, src:other-local
---

# Restaurant Kitchen Manager Tackled and Detained While Observing ICE

## Summary
The kitchen manager at Francis Burger Joint's East Lake Street location in Minneapolis was tackled, punched repeatedly, and detained by federal agents on January 13 while acting as a legal observer during a nearby ICE operation. The manager, a white U.S. citizen, had his shoes knocked off during the violent arrest. He was detained despite having no connection to the enforcement action other than observing it.

## Sources
1. Mpls.St.Paul Magazine (Jan 16, 2026): [When ICE Targets Your Restaurant](https://mspmag.com/eat-and-drink/foodie/when-ice-targets-your-restaurant/)
2. Francis Burger Joint (Jan 15, 2026): [Instagram post](https://www.instagram.com/p/DTdqQFSksuR/)
3. Francis Burger Joint (Jan 15, 2026): [Facebook post](https://www.facebook.com/share/p/1C8XtJe1Ec/)

## Affected Individual(s)
- **Name:** Not disclosed
- **Role:** Kitchen manager at Francis Burger Joint
- **Citizenship:** U.S. citizen
- **Race:** White
- **Background:** Restaurant employee arriving for work shift

## Timeline
- **Tuesday, Jan 13** - Kitchen manager arrives at Francis Burger Joint's East Lake Street location
- **During arrival** - ICE altercation already occurring nearby
- **Observation** - Manager runs over to act as legal observer; front-of-house staff follow
- **Arrest** - Manager is tackled, punched repeatedly, and detained
- **During arrest** - His kitchen shoes are knocked off

## Key Quotes

> "His shoes fell off. He had his kitchen shoes on, and they knocked his shoes off. That was the part that kept haunting me—that he was detained and he didn't have shoes on." — Lindsey Johnston, co-owner and head chef

## Aftermath
Following the January 13 detention of their kitchen manager, Francis Burger Joint closed temporarily. When the East Lake Street location reopened, the restaurant implemented new safety protocols including training all staff on asserting their right to legal representation.
