---
date: 2026-01-13
time: unknown
location: WCCO-TV Interview
city: Minneapolis
type: response
status: ongoing
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-15T23:23:27
last_updated: 2026-01-15T23:23:27
search_tags: src:wcco, src:cbs, src:other-national, src:abc, src:mpr
---

# Border Patrol Commander Bovino CBS Interview

## Summary
U.S. Border Patrol Commander Gregory Bovino sat down with WCCO's Esme Murphy for an interview defending ICE operations in Minnesota. During the interview, Bovino claimed "90% to 95% of Minnesotans" support the immigration crackdown and stated U.S. citizens have "no reason to be scared." CBS News noted they could not find any polling to support the 90-95% claim. Bovino's assurance to citizens is contradicted by documented cases of U.S. citizens detained, injured, and hospitalized during Minnesota operations.

## Sources
1. YouTube Video (Jan 13, 2026): [Full interview video](https://www.youtube.com/watch?v=ZDfQ-N4zXz8)
2. CBS Video (Jan 13, 2026): [Immigration officers agitate Minneapolis protesters despite Bovino claiming de-escalation efforts](https://www.cbsnews.com/video/immigration-officers-agitate-minneapolis-protesters-despite-bovino-claiming-de-escalation-efforts/)
3. CBS Minnesota (Jan 13, 2026): [Border Patrol Commander Bovino says "90% to 95% of Minnesotans" support immigration crackdown](https://www.cbsnews.com/minnesota/news/border-patrol-greg-bovino-interview-ice-end-immigration-crackdown-minneapolis/)
4. Meidas News (Jan 13, 2026): [Bovino says "hats off" to ICE agent who shot Renee Good](https://meidasnews.com/news/border-patrol-commander-bovino-says-hats-off-to-ice-agent-who-shot-renee-good)
5. YouGov (Jan 12, 2026): [More Americans view ICE shooting as unjustified](https://today.yougov.com/politics/articles/53878-more-americans-view-ice-shooting-minnesota-unjustified-than-justified-january-9-12-2026-economist-yougov-poll)
6. Axios (Jan 9, 2026): [Poll: Americans say ICE is "too forceful"](https://www.axios.com/2026/01/09/ice-approval-rating-plummets-trump-immigration)
7. ABC News (Jan 13, 2026): [Majority say Good shooting was inappropriate use of force](https://abcnews.go.com/Politics/majority-americans-ice-agents-shooting-good-unjustified-inappropriate/story?id=129253596)
8. The Daily Beast (Jan 13, 2026): [Trump's Top Goon Sparks Outrage by Praising ICE Agent](https://www.thedailybeast.com/donald-trumps-top-goon-sparks-outrage-by-praising-ice-agent-who-shot-mom-hats-off/)
9. MPR News (Jan 21, 2026): [Bovino defends immigration surge tactics, deflects questions, blames local leaders, 'anarchists'](https://www.mprnews.org/story/2026/01/21/bovino-defends-immigration-surge-tactics-deflects-questions-blames-local-leaders-anarchists)

## Key Claims and Context

### Claim: "90% to 95% of Minnesotans" support the crackdown
> "When I travel to Target or Costco or the Whipple Building, people are thanking me... I'm just going to give an estimate—I think 90% to 95% of Minnesotans—and it's just based on the feedback that I get—support what we do."

**CBS News Response:** "CBS News Minnesota could not find any recent Minnesota-centered polling to verify Bovino's claim."

**Actual Polling (January 2026):**
- [YouGov/Economist poll](https://www.axios.com/2026/01/09/ice-approval-rating-plummets-trump-immigration) (Jan 8, 2026): 52% of Americans disapprove of how ICE is handling its job
- [YouGov/Economist](https://www.axios.com/2026/01/09/ice-approval-rating-plummets-trump-immigration): 51% say ICE tactics are "too forceful" vs. 27% who say "about right"
- [CNN/SSRS poll](https://abcnews.go.com/Politics/majority-americans-ice-agents-shooting-good-unjustified-inappropriate/story?id=129253596) (Jan 9-12, 2026): 56% say ICE agent's use of force in Good shooting was "inappropriate"
- [YouGov tracking data](https://www.axios.com/2026/01/09/ice-approval-rating-plummets-trump-immigration): ICE net approval fell 30 percentage points in one year (from +16 in Feb 2025 to -14 in Nov 2025)

### Claim: Citizens have "no reason to be scared" (at 0:18)
> "Those individuals that are worried, if they're United States citizens or legal permanent residents, or have some type of legal status to be or remain here in the United States, there's no reason to be scared."

**Documented U.S. Citizens Detained in Minnesota:**

| Name | Date | What Happened |
|------|------|---------------|
| **Renee Good** | Jan 7, 2026 | Shot and killed by ICE agent while observing operations |
| **Shawn Jackson** | Jan 14, 2026 | Children (6 months to 11 years) tear-gassed; baby stopped breathing |
| **Aliya Rahman** | Jan 13, 2026 | Dragged from car, denied medical care, hospitalized for assault injuries |
| **Ryan Ecklund** | Jan 13, 2026 | Detained 9+ hours for filming agents; visible facial bruises |
| **Christian Molina** | Jan 12, 2026 | Car rammed by ICE; released after confirming citizenship |
| **Target Employees** | Jan 8, 2026 | Two citizens tackled, injured; one reportedly left "bleeding" at Walmart |
| **Jose Ramirez** | Jan 8, 2026 | Native American citizen punched and detained |
| **Sue Tincher** | Dec 9, 2025 | 55-year-old detained 5 hours observing; wedding ring cut off |
| **Mubashir Khalif Hussen** | Dec 10, 2025 | Tackled during lunch break; choked; fingerprinted |
| **Abdikadir Noor** | Dec 16, 2025 | Citizen detained at Karmel Mall; agent made racist statements |
| **Adnan Hisri** | Dec 14, 2025 | Rep. Omar's son stopped leaving Target; released after showing passport |
| **Mahamed Eydarus** | Dec 10, 2025 | Citizen detained; repeatedly told agents he was citizen |

### Claim: De-escalation efforts underway
> "Every day we de-escalate."

**CBS News Observation:** Reporter Nicole Sganga described agents walking "directly in front of the demonstrators," "telling them to move back, antagonizing them, getting up into their faces" — contradicting Bovino's claim.

### On Agent Who Shot Renee Good: "Hats off"
In a separate Fox News interview with Sean Hannity, Bovino praised the agent who shot Renee Good:

> "Hats off to that ICE agent. I'm glad he made it out alive."

He described Good's Honda Pilot as "a 4,000-pound missile" and characterized the shooting as justified.

**Public Response:** The comment [drew widespread criticism on social media](https://www.thedailybeast.com/donald-trumps-top-goon-sparks-outrage-by-praising-ice-agent-who-shot-mom-hats-off/). Author Don Winslow posted: "Listen very carefully to this. This is who they are and this is the world they want."

### On Duration of Operations
> "We'll be here til the mission is complete... as long as it takes."

Bovino indicated there is no defined end date for Operation Metro Surge.

## Notable Omissions

The interview did not address:
- Specific cases of U.S. citizens detained or injured
- The hospitalization of Aliya Rahman after being denied medical care
- The tear-gassing of six children, including a 6-month-old baby
- Reports from multiple news outlets documenting citizen detentions
