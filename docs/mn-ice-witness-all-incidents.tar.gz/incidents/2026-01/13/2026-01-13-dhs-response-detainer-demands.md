---
date: 2026-01-13
time: unknown
location: DHS Official Statement
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-14T13:57:51
last_updated: 2026-01-14T13:57:51
search_tags: src:fox-news, src:other-local
---

# DHS Demands Minnesota Honor 1,360+ ICE Detainers

## Summary
DHS issued a statement demanding Governor Tim Walz and Minneapolis Mayor Jacob Frey honor ICE arrest detainers for "more than 1,360 criminal illegal aliens" in state custody. DHS claimed Walz has "released nearly 470 criminal illegal aliens back onto the streets" since President Trump took office. The Walz administration disputed these numbers, stating only 207 people are on ICE detainers in the Minnesota prison system.

## Sources
1. DHS (Jan 13, 2026): [DHS Calls on Governor Walz and Mayor Frey to Honor ICE Arrest Detainers](https://www.dhs.gov/news/2026/01/13/dhs-calls-governor-walz-and-mayor-frey-honor-ice-arrest-detainers-more-1360)
2. Fox News (Jan 13, 2026): [DHS demands MN leaders honor ICE detainers](https://www.foxnews.com/politics/dhs-demands-mn-leaders-honor-ice-detainers-alleges-hundreds-criminal-aliens-have-been-released-under-walz)
3. Valley News Live (Jan 13, 2026): [DHS demands Minnesota honor ICE detainers for 1,360 People](https://www.valleynewslive.com/2026/01/13/dhs-demands-minnesota-honor-ice-detainers-1360-people-cites-criminal-cases/)

## Official Statements

### DHS Assistant Secretary Tricia McLaughlin
> "We are calling on Walz and Frey to stop this dangerous policy and commit to honoring the ICE arrest detainers of the more than 1,360 criminal illegal aliens in Minnesota's custody."

> "Criminal illegal aliens should not be released back onto our streets to terrorize more innocent Americans."

### DHS Key Claims
- **1,360+** people in Minnesota custody with outstanding ICE detainers
- **470** "criminal illegal aliens" allegedly released by Governor Walz since President Trump took office
- Both Walz and Frey "refuse" to cooperate with federal immigration officials.

## Disputed Numbers

### Walz Administration Response
According to Governor Walz's office, there are only **207 people** on an ICE detainer currently in the Minnesota prison system - a significant discrepancy from DHS's claimed 1,360+.

The gap between 207 (state figure) and 1,360+ (DHS figure) has not been explained. DHS may be counting people in county jails, city lockups, and other local facilities beyond just state prisons.

## Context

### Legal Background
ICE detainers are requests for local law enforcement to hold individuals for up to 48 hours beyond their scheduled release so federal immigration agents can take custody. Many jurisdictions limit cooperation with such requests, citing:
- Legal concerns about holding people without judicial warrants.
- Community trust issues that affect policing.
- Constitutional due process questions.

### Broader Conflict
This statement came amid escalating tensions:
- One week after ICE agent Jonathan Ross shot and killed Renee Good.
- One day after Minnesota, Minneapolis, and St. Paul filed a lawsuit calling the ICE surge a "federal invasion".
- Mayor Frey previously told ICE to "get the f--- out" of Minneapolis.
- Governor Walz told the Trump administration to "leave Minnesota alone".
