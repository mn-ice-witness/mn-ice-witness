---
date: 2026-01-13
time: unknown
location: Eastside Co-op, 2551 Central Ave NE
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-14T08:01:12
last_updated: 2026-01-14T08:01:12
search_tags: observer-intimidated, us-citizen, excessive-force, src:fox9, src:wcco, src:bring-me-the-news, src:cnn, src:other-national, src:star-tribune
---

# City Council President Pushed by ICE Agent While Legally Observing

## Summary
Minneapolis City Council President Elliott Payne was shoved by a masked ICE agent while legally observing federal immigration enforcement outside the Eastside Co-op in Northeast Minneapolis. Payne shared video of the incident, highlighting concerns about treatment of all residents.

## Sources
1. KYMA (Jan 13, 2026): [Masked ICE agent shoves Minneapolis City Council president](https://kyma.com/decision-2024/national-politics/2026/01/13/masked-ice-agent-shoves-minneapolis-city-council-president/)
2. Bring Me The News (Jan 13, 2026): [List of major ICE raids in Minnesota on Tuesday, Jan. 13](https://bringmethenews.com/minnesota-news/list-of-major-ice-raids-in-minnesota-on-tuesday-jan-13)
3. Bluesky Video (Jan 13, 2026): [Elliott Payne's post](https://bsky.app/profile/elliottpayne.org/post/3mcbnjlu7ms22)
4. CBS Minnesota (Jan 15, 2026): [Video shows federal agent shoving Minneapolis City Council president](https://www.cbsnews.com/minnesota/news/ice-federal-agent-shoves-minneapolis-city-council-president-elliot-payne/)
5. FOX 9 (Jan 15, 2026): [Minneapolis City Council president says he was 'assaulted' by ICE officers](https://www.fox9.com/news/minneapolis-city-council-president-says-he-was-assaulted-ice-officers)
6. The Mirror (Jan 15, 2026): [ICE agent captured violently shoving Minneapolis city official](https://www.themirror.com/news/us-news/ice-agent-captured-violently-shoving-1618728)
7. Mediaite (Jan 15, 2026): [Minneapolis City Council President Fears ICE Will 'Kill' Him While Documenting Protester Takedowns](https://www.mediaite.com/media/tv/minneapolis-city-council-president-fears-ice-will-kill-him-while-documenting-protester-takedowns/)
8. Augusta Free Press (Jan 15, 2026): [Minneapolis City Council leader on ICE: 'Worried that they'll kill me'](https://augustafreepress.com/news/minneapolis-city-council-leader-on-ice-im-worried-that-theyll-kill-me/)
9. uPolitics Video (Jan 15, 2026): [Masked ICE Agent Shoves Minneapolis City Council President Elliott Payne On Public Sidewalk](https://upolitics.com/news/video-masked-ice-agent-shoves-minneapolis-city-council-president-elliott-payne-on-public-sidewalk/)
10. Yahoo News Video (Jan 15, 2026): [Masked ICE agent shoves Minneapolis City Council president](https://www.yahoo.com/news/videos/masked-ice-agent-shoves-minneapolis-183434740.html)
11. CNN Live Updates (Jan 15, 2026): [Minneapolis shootings and protests](https://www.cnn.com/us/live-news/minneapolis-ice-shooting-protests-01-15-26?post-id=cmkfudw7f001m356pt806xv4f)
12. Star Tribune (Jan 15, 2026): ['Have y'all not learned': Federal agents target legal observers in the aftermath of Good shooting](https://www.startribune.com/have-yall-not-learned-federal-agents-target-legal-observers-in-the-aftermath-of-good-shooting/601562804)

## Affected Individual(s)
- **Name:** Elliott Payne
- **Position:** Minneapolis City Council President
- **Citizenship:** U.S. Citizen
- **Activity:** Legally observing ICE operations in his ward

## Timeline
- **Unknown time** - Payne observing ICE activities outside Eastside Co-op at 2551 Central Ave NE
- **Confrontation** - ICE agents stop a citizen in front of the co-op
- **Assault** - Masked ICE agent shoves Payne at a bus stop
- **Aftermath** - Payne shares video to Bluesky

## Affected Individual Statement

### Elliott Payne
"If this is how they treat the President of the Minneapolis City Council who is legally observing, just think of what they're doing to everyone else in our City."

## Context
The incident occurred as Attorney General Keith Ellison, along with mayors of St. Paul and Minneapolis, filed a federal lawsuit against the Trump administration to end the surge of ICE agents. Ellison noted the number of ICE agents in the Twin Cities (~2,000) surpasses the combined police forces of Minneapolis and St. Paul.
