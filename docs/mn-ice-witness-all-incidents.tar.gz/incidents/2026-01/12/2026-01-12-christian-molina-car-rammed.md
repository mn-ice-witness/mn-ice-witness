---
date: 2026-01-12
time: 12:00
location: East 35th Street near Park Avenue
city: Minneapolis
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-14T08:01:12
last_updated: 2026-01-14T08:01:12
search_tags: us-citizen, citizen-check, excessive-force, vehicle-pursuit, src:sahan-journal, src:nbc, src:npr, src:star-tribune, src:other-national
---

# ICE Rams Latino U.S. Citizen's Car, Releases Him After Confirming Identity

## Summary
ICE agents followed and rammed into the car of Christian Molina, a 40-year-old Latino U.S. citizen, two blocks from where Renee Nicole Good was killed. After demanding ID based on his appearance, agents released him when he proved citizenship. Molina described it as racial profiling.

## Sources
1. Facebook Video (Jan 12, 2026): [Bystander video of confrontation](https://www.facebook.com/reel/25653722154282706)
2. Sahan Journal (Jan 12, 2026): [ICE rams car in south Minneapolis while profiling Latino driver](https://sahanjournal.com/public-safety/ice-rams-latino-man-car-south-minneapolis-immigration/)
3. Democracy Now (Jan 13, 2026): [ICE Agents in Minneapolis Fire Tear Gas, Pepper Spray at Protests over Immigration Raids](https://www.democracynow.org/2026/1/13/headlines/ice_agents_in_minneapolis_fire_tear_gas_pepper_spray_at_protests_over_immigration_raids)
4. NBC News (Jan 13, 2026): [Immigration agents deploy tear gas, pepper spray in Minneapolis as confrontations with protesters grow](https://www.nbcchicago.com/news/national-international/immigration-ice-protests-minneapolis-renee-good-shooting/3875654/)
5. NPR (Jan 16, 2026): [ICE surge sparks fear and resistance in Minneapolis](https://www.npr.org/2026/01/16/nx-s1-5677712/ice-surge-sparks-fear-and-resistance-in-minneapolis)
6. MS NOW (Jan 13, 2026): [Clashes escalate between protesters, immigration officers in Minneapolis](https://www.ms.now/news/clashes-escalate-between-protesters-immigration-officers-in-minneapolis)
7. Star Tribune (Jan 18, 2026): [Allegations of racial profiling of U.S. citizens on the rise as ICE surge expands in Minnesota](https://www.startribune.com/allegations-of-racial-profiling-of-us-citizens-on-the-rise-as-ice-surge-expands-in-minnesota/601564653)
8. Court Filing (Jan 16, 2026): [Declaration re: Molina incident, Hussen v. Noem Case 26-cv-00324](https://www.justsecurity.org/pdfs/mn-ice-enforcement/Hussen%20Doc%2092-4.pdf)
9. Instagram Reel (Jan 12, 2026): [Witness footage of ICE ramming Molina's car](https://www.instagram.com/reel/DTbubTvgFBi/)

## Affected Individual(s)
- **Name:** Christian Molina
- **Age:** 40
- **Citizenship:** U.S. Citizen
- **Wife:** Lorena Molina, 34

## Timeline
- **~Noon** - ICE agents follow Molina's vehicle on E. 35th Street near Park Avenue
- **Collision** - Agents ram into the back of his car
- **Confrontation** - Agents ask about citizenship, request ID
- **Refusal** - Molina refuses to comply, states he's a citizen and they'd need police
- **Crowd gathers** - Observers arrive, blowing whistles and honking horns
- **Release** - Agents release Molina after confirming his identity

## Affected Individual Statement

### Christian Molina
"Because I look Latino, that's it, I don't look white or got blue eyes."

On the confrontation: He refused to show ID, stating he is a U.S. citizen and they would need to call police for identification.

## Witnesses
Minneapolis City Council Member Jason Chavez arrived at the scene. A crowd of observers quickly gathered, blowing whistles and honking horns to support Molina.

## Aftermath
- Car sustained significant rear damage
- Agent mentioned ICE would cover repairs but provided no contact information
- Molina experienced lower back pain
- Supporters began GoFundMe campaign for repairs and family expenses

## Location Context
The incident occurred two blocks from where Renee Nicole Good was killed by an ICE agent on January 7.

## DHS Response
Assistant Secretary Tricia McLaughlin stated that ICE officers were conducting surveillance on a target when "an agitator's reckless driving caused the officer to get in a car wreck."

**Contradicted by Molina**, who stated he was targeted based on his appearance and that ICE agents deliberately rammed into his car from behind.
