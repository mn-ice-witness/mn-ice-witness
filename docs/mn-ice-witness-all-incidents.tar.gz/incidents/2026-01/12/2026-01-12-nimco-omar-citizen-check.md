---
date: 2026-01-12
time: unknown
location: Near 24 Somali Mall
city: Minneapolis
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-14T17:54:18
last_updated: 2026-01-14T17:54:18
search_tags: us-citizen, citizen-check, src:nbc, src:fox9, src:other-national
---

# Citizen Check: U.S. Citizen Confronted by ICE Agents While Walking

## Summary
Nimco Omar, a U.S. citizen and Somali American, was surrounded by four masked federal agents who demanded her identification during what they called a "citizen check" while she was walking near 24 Somali Mall in Minneapolis. Omar refused to show ID, asserting her constitutional rights. After repeatedly asking "Where were you born?" and photographing her without permission, the agents eventually walked away.

## Sources
1. NBC Nightly News (Jan 12, 2026): [NBC Nightly News coverage](https://www.youtube.com/watch?v=ZEQPTTkV7ms&t=102s)
2. NBC Nightly News (Jan 12, 2026): [NBC News coverage](https://www.youtube.com/watch?v=Rsy6FDbOa3U&t=92)
3. Instagram Video (Jan 12, 2026): [Original video posted by Nimco Omar](https://www.instagram.com/reel/DTb0H8iAQTe/)
4. X Video (Jan 12, 2026): [FOX 9 coverage on X](https://x.com/FOX9/status/2010898391388000482)
5. Facebook Video (Jan 12, 2026): [Facebook reel of encounter](https://www.facebook.com/reel/853406107488988)
6. FOX 9 (Jan 12, 2026): [Minneapolis woman calmly resists ICE demand for ID, birth country](https://www.fox9.com/news/minneapolis-woman-calmly-resists-ice-demand-id-birth-country)
7. Common Dreams (Jan 13, 2026): ['Where Were You Born?': ICE Demanding Citizens Show Their Papers in Minneapolis](https://www.commondreams.org/news/ice-citizen-checks-minneapolis)
8. The Real News (Jan 14, 2026): ['Where were you born?' ICE conducting show-me-your-papers stops in Minnesota neighborhoods](https://therealnews.com/ice-show-me-your-papers-stops-in-minnesota-neighborhoods)
9. Yahoo News (Jan 13, 2026): [Woman Stands Firm Against Border Patrol Agent's Demand for ID in Minneapolis](https://www.yahoo.com/news/videos/woman-stands-firm-against-border-002529662.html)

## Affected Individual(s)
- **Name:** Nimco Omar
- **Age:** Not disclosed
- **Occupation:** Not disclosed
- **Citizenship:** U.S. Citizen
- **Background:** Somali American resident of Minneapolis

## Timeline
- **Afternoon** - Omar parks her car and begins walking toward 24 Somali Mall.
- **Initial contact** - Four masked agents jump out of a car and surround her.
- **Questioning** - Agent asks: "Do you have an ID on you, ma'am?"
- **Refusal** - Omar responds: "I don't need an ID to walk around in my city. This is my city."
- **Assertion** - Omar states: "I am a US citizen. I don't need to carry around an ID in my home. This is my home."
- **Threat** - Agent warns: "If not, we're going to put you in the vehicle, and we're going to ID you."
- **Repeated questioning** - Agent repeatedly asks "Where were you born?"
- **Photo taken** - Agent photographs Omar without permission, likely for facial recognition.
- **Resolution** - After failing to obtain answers, agents walk away.

## Official Accounts

### DHS/ICE Statement
No specific statement on this incident. Agents told Omar they were conducting an "immigration check" and "citizen check."

### Local Officials
**Minnesota Attorney General Keith Ellison:**
Cited this incident as evidence of "unlawful racial profiling by DHS agents" in the state's lawsuit against DHS filed January 12, 2026.

## Witness Accounts

**Nimco Omar's account:**
> "I parked my car and began walking toward the 24 Somali Mall where suddenly four men who looked like soldiers suddenly jumped out of a car and surrounded me. They told me they needed to verify whether I was a citizen."

> "I don't need an ID to walk around in my city. This is my city."

> "I am a US citizen. I don't need to carry around an ID in my home. This is my home."

> "I'm a US citizen. I don't have to identify myself. I belong here—and it doesn't matter where I was born."

> "I was scared. I was devastated. I never imagined that something like this could happen to me in the United States."

## Legal Context
There is no federal law requiring U.S. citizens to carry proof of their citizenship. Immigration agents are barred from carrying out indiscriminate searches unless they have reasonable suspicion to believe that someone is in the country without authorization. No such thing as a "citizen check" exists in American law.
