---
date: 2026-01-20
time: unknown
location: Truth Social
city: n/a
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-20T12:00:00
last_updated: 2026-01-20T12:00:00
search_tags:
---

# Trump Claims ICE Operation is About Removing "Murderers and Other Criminals" from Minnesota, Calls Protesters "Highly Paid Troublemakers, Anarchists, and Agitators"

## Summary
President Donald Trump posted on Truth Social claiming ICE is capturing "murderers and other criminals" and that there are "thousands of vicious animals in Minnesota alone." He called on supporters to back "the patriots of ICE, instead of the highly paid troublemakers, anarchists, and agitators."

## Sources
1. Truth Social (Jan 20, 2026): [Trump post on ICE operations](https://truthsocial.com/@realDonaldTrump/posts/115928309252078004)
2. Bluesky (Jan 20, 2026): [Aaron Rupar repost](https://bsky.app/profile/atrupar.com/post/3mcuklhth522i)

## Official Statement

Full statement from President Donald Trump on Truth Social:

> The Department of Homeland Security and ICE must start talking about the murderers and other criminals that they are capturing and taking out of the system. They are saving many innocent lives! There are thousands of vicious animals in Minnesota alone, which is why the crime stats are, nationwide, the BEST EVER RECORDED! Show the numbers, names, and faces of the violent criminals, and show them NOW. The people will start supporting the patriots of ICE, instead of the highly paid troublemakers, anarchists, and agitators! MAKE AMERICA GREAT AGAIN

## Context

This statement is part of a series of posts from President Trump regarding the Minnesota ICE operations. Earlier this month, Trump threatened to invoke the Insurrection Act against Minnesota if state and local officials did not stop interfering with ICE operations.

On January 15, 2026, Trump wrote on Truth Social: "If the corrupt politicians of Minnesota don't obey the law and stop the professional agitators and insurrectionists from attacking the Patriots of I.C.E., who are only trying to do their job, I will institute the INSURRECTION ACT, which many Presidents have done before me, and quickly put an end to the travesty that is taking place in that once great State."

Trump has repeatedly characterized protesters as "highly paid professionals," "troublemakers, agitators, and insurrectionists," and "thugs." He has also referred to Minnesota officials including Governor Tim Walz and Representative Ilhan Omar as "corrupt politicians" who have "totally lost control."

In late 2025, Trump said "Somalian gangs are roving the streets looking for 'prey.'"
