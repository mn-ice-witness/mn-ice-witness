---
date: 2026-01-18
time: morning
location: CBS Face the Nation Interview
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-18T22:01:07
last_updated: 2026-01-18T23:55:30
search_tags: chemical-agents, src:cbs, src:nyt, src:nbc
---

# DHS Secretary Noem Defends Raids as Targeting 'Criminals and Rapists,' Denies Pepper Spray Use on CBS

## Summary
Homeland Security Secretary Kristi Noem denied on CBS's "Face the Nation" that federal agents had used pepper spray and similar tactics curtailed by a judicial order, claiming the judge "told us we couldn't do what we already aren't doing." When CBS showed video evidence, Noem shifted her position, stating agents "only use those chemical agents when there's violence happening."

## Sources
1. CBS News (Jan 18, 2026): [Transcript: Homeland Security Secretary Kristi Noem on "Face the Nation"](https://www.cbsnews.com/news/kristi-noem-face-the-nation-transcript-01-18-2026/)
2. CBS News (Jan 18, 2026): [Noem defends Minnesota ICE operations, says judge's order "didn't change anything"](https://www.cbsnews.com/news/noem-defends-minnesota-ice-operations-says-judges-order-didnt-change-anything/)
3. New York Times (Jan 18, 2026): [Noem Denies Use of Chemical Agents in Minnesota, Then Backtracks](https://dnyuz.com/2026/01/18/noem-denies-use-of-chemical-agents-in-minnesota-then-backtracks/)
4. NBC News (Jan 16, 2026): [Judge orders federal agents to stop pepper spraying, retaliating against peaceful Minnesota protesters](https://www.nbcnews.com/news/us-news/us-judge-orders-federal-agents-stop-pepper-spraying-retaliating-peacef-rcna254514)

## Timeline
- **Jan 16, 2026** - Federal Judge Katherine Menendez issues preliminary injunction barring federal agents from using pepper spray on peaceful protesters.
- **Jan 18, morning** - Noem appears on CBS "Face the Nation" with Margaret Brennan.
- **During interview** - Noem claims judge's order was "a little ridiculous" and "didn't change anything."
- **During interview** - CBS shows video evidence of chemical agent use.
- **During interview** - Noem shifts position, says agents use chemical agents "when there's violence happening."

## Official Statement

### Initial Denial
When asked about the federal court order restricting chemical agent use, Noem stated:

> "That federal order was a little ridiculous, because that federal judge came down and told us we couldn't do what we already aren't doing."

> "That judge's order didn't change anything for how we're operating on the ground, because it's basically telling us to do what we've already been doing."

### Subsequent Statement
After CBS showed video evidence consistent with accounts provided to the court, Noem stated:

> "We only use those chemical agents when there's violence happening and perpetuating and you need to be able to establish law and order to keep people safe."

## Court Record

### Judge Menendez's Findings
The federal court found that chemical agents were used against protesters on at least four separate occasions. Judge Menendez ruled that the evidence of chemical agent use was "uncontroverted" and found the government's claims that all such deployments occurred only after agents were attacked to be unsupported by the record.

The court determined that "protected conduct—including peaceful protesting and observation—had motivated the agents' actions" and that federal agents deployed substances to punish protesters exercising "protected First Amendment rights to assemble and to observe and protest ICE operations."

### CBS Polling Data
In polling released alongside the interview:
- 54% of Americans say Good's shooting was not justified.
- 61% of Americans describe ICE's detention tactics as "too tough" (up from 56% in November).

## Related Incidents
- [Clergy Pepper Sprayed at Federal Building](#2026-01-07-clergy-pepper-sprayed) (Jan 7).
- [Two ICE Observers Pepper-Sprayed in Car, Detained 8 Hours](#2026-01-11-siguenza-okeefe-detained) (Jan 11).
- [Two Young Women Sprayed Directly in Face in Mankato](#2026-01-13-mankato-women-sprayed) (Jan 13).
- [Lyn-Lake Tear Gas Deployment](#2026-01-13-lyn-lake-tear-gas) (Jan 13).
- [Shawn Jackson Children Tear Gassed](#2026-01-14-shawn-jackson-children-tear-gas) (Jan 14).
