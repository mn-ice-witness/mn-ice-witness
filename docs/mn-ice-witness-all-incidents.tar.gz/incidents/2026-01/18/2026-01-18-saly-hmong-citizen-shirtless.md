---
date: 2026-01-18
time: unknown
location: East Side
city: St. Paul
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-19T10:14:30
last_updated: 2026-01-22T15:40:03
search_tags: us-citizen, excessive-force, warrantless-entry, shooting, children, src:star-tribune, src:fox9, src:wcco, src:nbc, src:other-local, src:other-national, src:bring-me-the-news, src:mpr, src:abc, src:pbs, src:kstp
---

# Hmong U.S. Citizen Detained Shirtless in Freezing Weather, Then Released

## Updates
- **Jan 22** - [KSTP investigation](https://kstp.com/kstp-news/top-news/man-ice-sought-in-humiliating-arrest-of-us-citizen-has-been-in-prison-since-2024/) reveals one of ICE's targets (Lue Moua) has been in state prison since September 2024; the other (Kongmeng Vang) got a driver's license at a Circle Pines address, not the Thao residence

## Summary
A Hmong man named Saly, described as a naturalized U.S. citizen with no criminal record, was reportedly detained by ICE agents who broke down his apartment door. According to family members, agents did not allow him to put on proper clothing before taking him outside in approximately 10-degree weather. After driving him around for nearly an hour, questioning, and fingerprinting him, agents released him after determining he had no criminal history. The family believes ICE was searching for someone who previously lived at the address.

## Sources
1. Facebook Video (Jan 18, 2026): [Hmong American Experience page - Louansee Moua](https://www.facebook.com/share/v/18GcBq3Rwb/)
2. Facebook Post (Jan 19, 2026): [Georgia Fort](https://www.facebook.com/ByGeorgiaFort/posts/update-multiple-members-of-the-hmong-community-confirm-the-man-taken-from-his-ea/1400574674857282/)
3. Threads (Jan 19, 2026): [@don.moyn post](https://www.threads.com/@don.moyn/post/DTsao6ijVAd)
4. Facebook Video (Jan 18, 2026): [Incident footage](https://www.facebook.com/reel/1986120352306275)
5. Star Tribune (Jan 19, 2026): [St. Paul mayor 'livid' after ICE wrongly targets family friend](https://www.startribune.com/st-paul-mayor-livid-after-ice-wrongly-targets-family-friend-escorts-him-undressed-into-cold/601566974)
6. FOX 9 (Jan 19, 2026): [St. Paul ICE raid: Elderly citizen taken in shorts and Crocs](https://www.fox9.com/news/st-paul-ice-raid-elderly-citizen-taken-shorts-crocs)
7. CBS Minnesota (Jan 20, 2026): [ICE arrests elderly Hmong-American citizen in St. Paul](https://www.cbsnews.com/minnesota/news/ice-elderly-hmong-american-citizen-arrested-st-paul/)
8. NBC News (Jan 19, 2026): [U.S. citizen shares fear he felt when ICE took him from Minnesota home while nearly naked](https://www.nbcnews.com/news/us-news/us-citizen-shares-fear-felt-ice-took-minnesota-home-nearly-naked-rcna254890)
9. Detroit News (Jan 19, 2026): [Hmong elder, a U.S. citizen, forced from Minnesota home at gunpoint, family says](https://www.detroitnews.com/story/news/nation/2026/01/19/hmong-elder-a-u-s-citizen-forced-from-minnesota-home-at-gunpoint-family-says/88258005007/)
10. Raw Story (Jan 19, 2026): [ICE forces showering citizen outside into freezing weather in his underwear](https://www.rawstory.com/ice-us-citizen/)
11. The Handbasket (Jan 19, 2026): [Behind the disturbing image of ICE snatching a half-naked, elderly Hmong American from his home](https://www.thehandbasket.co/p/ice-st-paul-chongly-scott-thao-saly-hmong-us-citizen-arrest)
12. Bring Me The News (Jan 19, 2026): [Video: ICE agents raid St. Paul home, detain elderly US citizen on frigid Sunday](https://bringmethenews.com/minnesota-news/video-ice-agents-raid-st-paul-home-detain-elderly-us-citizen-on-frigid-sunday)
13. KFGO (Jan 19, 2026): [Hmong grandfather arrested by ICE in his home; brought out wearing underwear and sandals](https://kfgo.com/2026/01/19/1248604/)
14. Spokesman Review (Jan 19, 2026): [ICE broke into Minnesota home, dragged barely clothed man into snow](https://www.spokesman.com/stories/2026/jan/19/ice-broke-into-minnesota-home-dragged-barely-cloth/)
15. MPR News (Jan 20, 2026): [ChongLy "Scott" Thao says ICE removed him from home in his underwear after warrantless search](https://www.mprnews.org/story/2026/01/20/chongly-scott-thao-says-ice-removed-him-from-home-in-his-underwear-after-warrantless-search)
16. PBS News (Jan 20, 2026): [A U.S. citizen says ICE forced open the door to his Minnesota home](https://www.pbs.org/newshour/nation/a-u-s-citizen-says-ice-forced-open-the-door-to-his-minnesota-home-and-removed-him-in-his-underwear-after-a-warrantless-search)
17. The Hill (Jan 20, 2026): [WATCH: ICE removes citizen from Minnesota home in his underwear](https://thehill.com/homenews/state-watch/5696306-minnesota-man-detained-ice-agents/)
18. KSTP (Jan 22, 2026): [Man ICE sought in "humiliating" arrest of US citizen has been in prison since 2024](https://kstp.com/kstp-news/top-news/man-ice-sought-in-humiliating-arrest-of-us-citizen-has-been-in-prison-since-2024/)

## Affected Individual(s)
- **Name:** ChongLy Scott Thao (also referred to as "Saly" by family)
- **Citizenship:** Naturalized U.S. citizen (per family account)
- **Criminal Record:** None (per family account)
- **Medical Condition:** Severe psoriasis, exacerbated by extreme cold and stress
- **Background:** Son of Nurse Choua Thao, a pioneering Hmong nurse who worked at Sam Thong Hospital in Laos during the Secret War and later settled in St. Paul, Minnesota.

## Timeline
- **Unknown time** - ICE agents arrive at Saly's apartment.
- **During encounter** - Agents break down door, search apartment.
- **During encounter** - Agents reportedly point gun at daughter-in-law's head.
- **During encounter** - Saly handcuffed, not allowed to dress properly.
- **During encounter** - Taken outside shirtless in freezing weather (~10°F).
- **~1 hour later** - After questioning and fingerprinting, agents determine no criminal record.
- **After processing** - Saly released and returned to apartment.

## Official Accounts

### DHS/ICE Statement
See: [DHS Response: Defends Detention of Hmong Citizen](#2026-01-19-dhs-response-saly-detention) - Statement from @TriciaOhio claims ICE was targeting two convicted sex offenders at the address who remain "at large."

### Family Rebuttal (January 19, 2026)
The family issued a formal press release on the same day categorically disputing all DHS claims. Key points from the family statement:
- Mr. Thao is a U.S. citizen with no criminal record.
- He does not live with, nor has ever lived with, the individuals DHS claims.
- Only people at the home are Mr. Thao, his son, daughter-in-law, and young grandson.
- They do not know the individuals DHS references.
- ICE did NOT present a warrant and did NOT ask for identification.
- ICE agents forcibly entered the home with weapons drawn.
- Mr. Thao went willingly despite knowing he had done nothing wrong.
- He suffers from severe psoriasis, exacerbated by the cold exposure.

The family has filed complaints with the ACLU of Minnesota and the Office of Minnesota Attorney General Keith Ellison.

### Local Officials

#### St. Paul Mayor Kaohly Her (January 19-20, 2026)
Mayor Her, who has a personal connection to the Thao family, said she was "livid" about the incident. She visited the family after the raid.

**Personal Connection:** Mayor Her stated that Thao's mother was friends with her mother-in-law in Laos and that the families go back decades. "These are people who were looked at as my own uncles as I was growing up and it is unbelievable to me," she said.

**Criticism of ICE Conduct:**
- "This is an American citizen who has no criminal record, who was sleeping in his own house, that they broke a door down and put guns to his daughter-in-law's head."
- "They didn't ask for ID. They didn't ask to verify if it was the right person."
- Characterized the DHS statement as "irresponsible and reckless."
- Noted the family has lived in the home for two years and the person ICE was looking for does not live there anymore.

**Community Concern:** Mayor Her raised concerns about the impact on the Hmong-American community, noting heightened fear of ICE exceeding historical anxieties from Laos.

## Witness Accounts
From Louansee Moua's Facebook post (Saly's sister-in-law):

"ICE came to my brother-in-law Saly's apartment, broke down the door, trashed the place, handcuffed him, and put a gun to his daughter-in-law's head. They did not allow him to put on proper clothing and forced him outside in freezing weather."

"Saly is a naturalized U.S. citizen. He has NO criminal record."

"ICE drove him around for nearly an hour, questioned him, and fingerprinted him. Only after all of that did they realize he had no criminal history and no reason to be detained. They then dropped him back off at his apartment like nothing happened."

"We believe they were looking for someone who previously lived there, but instead of asking for identification, they chose violence, intimidation, and humiliation."

The post notes that Saly's mother, Choua Thao, was a nurse during the war in Laos who helped deliver premature twins. She ensured all her children became naturalized U.S. citizens.
