---
date: 2026-01-23
time: afternoon
location: Minneapolis Visit
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-23T20:50:18
last_updated: 2026-01-23T20:50:18
search_tags: children, src:nbc, src:abc, src:wcco, src:star-tribune, src:kare11, src:fox9, src:other-national
---

# Vice President Vance Defends 5-Year-Old's Detention: "What Are They Supposed to Do?"

## Summary

Vice President JD Vance visited Minneapolis on January 23, 2026, and addressed the detention of 5-year-old Liam Conejo Ramos. Vance defended ICE's actions, arguing the alternative would have been to "let a 5-year-old child freeze to death" and that exempting parents from arrest would grant universal immunity. Critics disputed his key claims, including the "freeze to death" scenario and his characterization of the family's legal status.

## Sources

1. NBC News Video (Jan 23, 2026): [Vance reacts to ICE detainment of 5-year-old boy in Minneapolis](https://www.nbcnews.com/now/video/vance-reacts-to-ice-detainment-of-5-year-old-boy-in-minneapolis-256411717612)
2. ABC News Video (Jan 23, 2026): [Vance responds after image shows 5-year-old detained by ICE](https://abcnews.go.com/GMA/News/video/vance-responds-after-image-shows-5-year-detained-129484344)
3. CBS Minnesota (Jan 23, 2026): [Vice President JD Vance says "failure of cooperation" by local, state authorities to blame for chaos](https://www.cbsnews.com/minnesota/news/jd-vance-minneapolis-visit-ice-operation/)
4. Star Tribune (Jan 23, 2026): [Witnesses dispute DHS claim that 5-year-old was 'abandoned' prior to ICE detainment](https://www.startribune.com/witnesses-dispute-dhs-claim-that-5-year-old-was-abandoned-prior-to-ice-detainment/601569307)
5. The New Republic (Jan 23, 2026): [Vance responds to 5-year-old detention](https://newrepublic.com/article/205616/jd-vance-minneapolis-ice-5-year-old)
6. Raw Story (Jan 23, 2026): [CNN host disputes Vance claim about 5-year-old detention](https://www.rawstory.com/ice-agents-detain-boy-freeze/)
7. KARE 11 (Jan 23, 2026): [Lawyer disputes Vance claims about 5-year-old arrest by ICE, 'inhumane and unacceptable'](https://www.kare11.com/article/news/local/ice-in-minnesota/lawyer-vance-5-year-old-arrest-ice-columbia-heights/89-f5f5b915-c6d5-4512-a846-364b98b465cf)
8. FOX 9 (Jan 23, 2026): [5-year-old detained by ICE in Columbia Heights: Family came into US the 'right' way](https://www.fox9.com/news/columbia-heights-child-ice-detained)
9. CBC News (Jan 23, 2026): [Minnesota officials, Trump administration offer very different takes on ICE's detainment of boy, 5](https://www.cbc.ca/news/world/ice-arrest-minnesota-preschooler-breakdown-9.7057414)

## Related Incidents

- [Five-Year-Old Liam Ramos Detained in Driveway, Allegedly Used as "Bait"](#2026-01-20-liam-ramos-detained)
- [Bovino: "We Are Experts in Dealing With Children"](#2026-01-23-bovino-experts-dealing-children)
- [DHS Response: "Child Was ABANDONED," Father "Fled on Foot"](#2026-01-21-dhs-response-5-year-old-bait)

## Vice President Vance's Statements

### Initial Acknowledgment

Vance began by acknowledging the emotional weight of the story:

> "I see the story, and I'm a father of a 5-year-old, actually, 5-year-old little boy. And I think to myself: 'Oh, my God, this is terrible. How did we arrest a 5-year-old?'"

### Reframing the Narrative

Vance then shifted to the administration's framing:

> "What I find is that the 5-year-old was not arrested, that his dad was an illegal alien. And then they went, when they went to arrest his illegal alien father, the father ran."

### The "Freeze to Death" Argument

Vance posed what he characterized as a binary choice:

> "So the story is that ICE detained a 5-year-old? Well, what are they supposed to do? Are they supposed to let a 5-year-old child freeze to death? Are they not supposed to arrest an illegal alien in the United States of America?"

### The Universal Immunity Argument

Vance argued exemptions would create a loophole:

> "If the argument is that you can't arrest people who have violated the law because they have children, then every single parent is going to be completely given immunity from ever being the subject of law enforcement."

### On Local Cooperation

Vance blamed local authorities for operational difficulties:

> "It would make our lives a lot easier... if we had a little bit of cooperation from the state and local officials."

He also asked why police wouldn't assist:

> "Why not just have the mayor... tell the police officers, 'If an ICE officer is being assaulted... you should actually help him.'"

### Acknowledging Mistakes

Vance conceded the possibility of errors:

> "Even if 99.99% of the guys do everything perfectly, you're going to have people that make mistakes."

## Points of Factual Dispute

### Dispute 1: The "Freeze to Death" Claim

**What Vance said:** The alternative to detaining the child was letting him "freeze to death."

**What critics point out:** CNN's Sara Sidner directly refuted this claim: "The five year old child was never in danger of freezing to death. There were school officials there who said that they were happy to take him to the safe place, back to school. There was a mother just behind the door... But this idea that this child was just left outside, was going to be left outside to freeze to death, is just simply not true."

Columbia Heights school board chair Mary Granlund told reporters she personally offered to take Liam back to school until his mother could retrieve him.

### Dispute 2: The "Illegal Alien" Characterization

**What Vance said:** The father was an "illegal alien."

**What the family's attorney says:** Attorney Marc Prokosch stated the family entered the U.S. legally through the CBP One app in 2024, presented themselves at an official port of entry, and has an active asylum case with no deportation order. Prokosch said: "They used the app, they made an appointment, they came to the border and presented themselves to Customs and Border Patrol... They did everything right when they came in."

Columbia Heights Superintendent Zena Stenvik also stated she viewed the family's legal paperwork: "This family is following U.S. legal parameters and has an active asylum case with no order of deportation."

**The legal nuance:** The family used CBP One, a Biden-era legal entry program for asylum seekers. Immigration advocates note this complicates the "illegal alien" characterization, as the family entered through official channels and had pending claims. The Trump administration has taken the position that asylum-seekers lack legitimacy regardless of having followed legal entry processes.

### Dispute 3: Who "Abandoned" Whom

**What the administration says:** DHS claimed the father "fled on foot—abandoning his child" when agents approached.

**What school officials say:** Superintendent Stenvik provided a different timeline: ICE agents took the child from the vehicle and led him to the front door, instructing him to knock to see if anyone else was home. In this account, ICE had custody of the child before any flight occurred.

### Unaddressed Allegation: "Bait"

Neither Vance nor DHS has directly addressed school officials' claim that ICE used the 5-year-old as "bait"—instructing him to knock on the door to draw out other family members. Vance's remarks focused on the "freeze to death" framing rather than the sequence of events alleged by school officials.

## Analysis

### The Administration's Framing

Vance presented the situation as a choice between detaining the child and letting him freeze. School officials have stated a third option was available: they offered to take the child back to school.

His "universal immunity" argument applies a general principle (you can't exempt all parents) to a specific case without addressing whether this particular family had legal status that should have affected the decision.

### Points Raised by Critics

1. **The "freeze to death" claim:** School officials who were present have stated they offered to care for the child, which would have provided an alternative to the scenario Vance described.

2. **Legal status characterization:** The family's attorney states they entered through CBP One with pending asylum claims. Describing someone with an active legal case as an "illegal alien" is disputed by immigration advocates.

3. **The "bait" allegation:** Vance's remarks focused on the "freeze to death" framing rather than addressing the allegation that agents instructed the child to knock on the door.

4. **Accountability:** Vance's statement that "you're going to have people that make mistakes" did not address whether this case represents such a mistake or what consequences would follow.
