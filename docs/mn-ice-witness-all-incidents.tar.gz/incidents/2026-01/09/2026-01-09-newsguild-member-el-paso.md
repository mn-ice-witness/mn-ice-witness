---
date: 2026-01-09
time: unknown
location: Minneapolis
city: Minneapolis
type: immigrants
status: ongoing
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-17T16:15:46
last_updated: 2026-01-17T16:15:46
search_tags: src:other-national
---

# NewsGuild Union Member Detained and Transferred to Texas

## Summary
A member of the Minnesota Newspaper and Communications Guild was detained by ICE as part of Operation Metro Surge. The individual was transferred to an ICE detention facility in El Paso, Texas, where they are awaiting action on a petition for habeas corpus.

## Sources
1. The NewsGuild (Jan 16, 2026): [Guild member detained by ICE in Minnesota](https://newsguild.org/guild-member-detained-by-ice-in-minnesota/)
2. Editor & Publisher (Jan 19, 2026): [Guild member detained by ICE in Minnesota](https://www.editorandpublisher.com/stories/guild-member-detained-by-ice-in-minnesota,259707)

## Affected Individual(s)
- **Name:** Not disclosed
- **Nationality:** Unknown
- **Status:** Unknown (member of Minnesota Newspaper and Communications Guild)

## Timeline
- **2026-01-09** - Individual detained by ICE during Operation Metro Surge
- **Unknown** - Transferred to ICE detention facility in El Paso, Texas
- **Ongoing** - Awaiting action on habeas corpus petition

## Official Accounts

### Union Statement
The Minnesota Newspaper and Communications Guild confirmed the detention of one of its members. Working Partnerships, a division of the Minneapolis Regional Labor Federation, is raising funds to assist affected union members with legal fees and other hardships.
