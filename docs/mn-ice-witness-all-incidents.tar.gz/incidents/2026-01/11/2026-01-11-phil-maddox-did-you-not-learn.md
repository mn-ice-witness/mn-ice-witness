---
date: 2026-01-11
time: morning
location: South Minneapolis
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-19T11:13:23
last_updated: 2026-01-19T11:13:23
search_tags: us-citizen, observer-intimidated, src:intercept, src:fox9, src:other-national
---

# "Did You Not Learn From What Just Happened?" - ICE Agents Threaten Observer

## Summary
Phil Maddox, a Minneapolis resident, was confronted by ICE agents while driving through his neighborhood to monitor federal activity. Agents accused him of following them, knocked on his car window, and made veiled death threats referencing the killing of Renee Good four days earlier, asking "Did you not learn from what just happened?" Maddox interpreted this as agents saying they have immunity to kill citizens.

## Sources
1. The Intercept (Jan 14, 2026): [Federal Agents Keep Invoking Killing of Renee Good to Threaten Protesters in Minnesota](https://theintercept.com/2026/01/14/ice-minneapolis-protests-renee-good/)
2. FOX 9 / YouTube (Jan 15, 2026): [ICE agents caught on video asking if people have 'learned their lesson'](https://www.youtube.com/watch?v=YpLT2RQc0lA)
3. Inquisitr (Jan 13, 2026): [Video Shows ICE Agent Threatening Man Going to Church](https://www.inquisitr.com/video-shows-ice-agent-threatening-man-going-to-church-did-you-not-learn-from-what-just-happened)
4. Raw Story (Jan 12, 2026): ['Did you not just learn?' ICE agents threaten MN churchgoer with Renee Good lesson](https://www.rawstory.com/renee-good-2674874951/)
5. Facebook Video (Jan 12, 2026): [Incident footage](https://www.facebook.com/reel/906204785493223)

## Affected Individual(s)
- **Name:** Phil Maddox
- **Citizenship:** U.S. citizen
- **Background:** Local Minneapolis resident monitoring federal agent activity in his neighborhood

## Timeline
- **Sunday morning** - Maddox drives around his south Minneapolis neighborhood to monitor ICE activity.
- **During drive** - Multiple ICE agents confront Maddox at his vehicle.
- **During confrontation** - Agent knocks on car window, shouts "Federal agent!"
- **During confrontation** - Agent accuses Maddox of "following" them.
- **During confrontation** - Maddox explains he lives in the area.
- **During confrontation** - Agent threatens: "You're not going to like the outcome of this, sir. I guarantee that."
- **During confrontation** - Agent asks: "Did you not learn from what just happened?" - referencing Renee Good's killing four days earlier.
- **End of encounter** - Maddox allowed to leave.

## Official Accounts

### DHS/ICE Statement
No official statement found regarding this specific incident.

### Local Officials
No statements from local officials found regarding this specific incident.

## Witness Accounts
Phil Maddox told The Intercept he recorded the video on Sunday morning during a quick drive around his neighborhood to keep tabs on federal agents in the area.

Maddox said he immediately interpreted the question as a threat: "They're saying, 'Get in our way and we'll shoot you. We have immunity, we can do what we want, and you should fear us.'"

Luis Argueta, a spokesperson for the immigrant rights group Unidos Minnesota, told The Intercept: "That's a veiled threat, 1,000 percent. They can't exactly say it, but the way they reference Renee Good — they're using that to strike fear."

## Related Pattern

The Intercept documented multiple ICE agents using similar language in separate encounters:
- In another video, an agent tells someone: "You don't fucking learn — what's fuckin' happened in the last couple of days."
- The same agent approaches a woman filming from a second vehicle: "Listen, have y'all not learned from the past couple of days? Have you not learned?"
- The woman responds: "Learned what? What's our lesson here? What do you want us to learn?"
