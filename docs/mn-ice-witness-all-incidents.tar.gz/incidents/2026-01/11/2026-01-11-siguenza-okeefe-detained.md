---
date: 2026-01-11
time: unknown
location: 16th Ave S & E 42nd Street
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-14T08:01:12
last_updated: 2026-01-14T08:01:12
search_tags: us-citizen, observer-detained, observer-intimidated, excessive-force, chemical-agents, children, src:kare11, src:sahan-journal, src:mpr, src:abc, src:ap, src:other-national
---

# Two ICE Observers Detained 8 Hours, Pressured to Name Organizers

## Summary
Brandon Sigüenza (32) and Patty O'Keefe (36), both U.S. citizens monitoring ICE, were detained 8 hours without charges. Agents pepper-sprayed their car, smashed windows, interrogated them about protest organizers, and offered deals for names.

## Sources
1. KARE 11 Video (Jan 13, 2026): [Brandon Sigüenza full interview](https://www.youtube.com/watch?v=Inn-sfiMcyE)
2. Sahan Journal (Jan 13, 2026): [Eight hours inside ICE custody at the Whipple Building](https://sahanjournal.com/immigration/ice-citizen-observer-detainment-minnesota-whipple-building/)
3. CATO Institute (Jan 13, 2026): [Terror in Minneapolis: The Ordeal of Brandon Sigüenza](https://www.cato.org/blog/terror-minneapolis-ordeal-brandon-siquenza)
4. MPR News (Jan 13, 2026): [Minnesotans describe their encounters with ICE agents](https://www.mprnews.org/episode/2026/01/13/minnesotans-describe-their-encounters-with-ice-agents)
5. Snopes (Jan 14, 2026): [What we know about ICE arrest, detention of observer Brandon Siguenza](https://www.snopes.com/news/2026/01/14/ice-arrest-brandon-siguenza/)
6. Cato Institute X (Jan 15, 2026): [@CatoInstitute post on Siguenza and O'Keefe](https://x.com/CatoInstitute/status/2011831267273138324)
7. Threads (Jan 15, 2026): [U.S. citizens Patty O'Keefe and Brandon Siguenza detained by ICE](https://www.threads.com/@klgfortexas/post/DTcRk2REkOI/)
8. USA Today Opinion (Jan 26, 2026): [ICE arrested me without cause. What I saw will haunt me forever.](https://www.usatoday.com/story/opinion/voices/2026/01/26/ice-detained-us-citizens-minnesota-arrests/88304880007/) | [Archive](https://archive.ph/sVibz)
9. Yahoo News Canada (Jan 26, 2026): [ICE arrested me without cause. What I saw will haunt me forever.](https://ca.news.yahoo.com/ice-arrested-without-cause-saw-164506774.html)
10. Slate (Jan 15, 2026): [I Was Legally Observing ICE Agents When They Turned Their Ire on Me](https://slate.com/news-and-politics/2026/01/arrested-for-observing-ice-minnesota-lesson.html)

## Affected Individual(s)
- **Patty O'Keefe:** 36, U.S. Citizen
- **Brandon Sigüenza:** 32, U.S. Citizen

## Treatment

### O'Keefe's Account (USA Today Opinion)
- Placed alone in car with three agents who taunted her
- Agent photographed her and showed it to others, laughing
- Agent called her "ugly"
- Agent stated: "You guys gotta stop obstructing us — that's why that lesbian bitch is dead" (referencing Renee Good)
- Shackled at ankles upon arrival at Whipple Federal Building
- Requested phone call four times — denied each time
- Had to beg for water and bathroom access
- Witnessed holding cells with men, women, and children (reportedly as young as 5) of Latino and East African descent
- Described "despondent faces" and "screaming, wailing and pleading" from detainees
- Agents nearby were laughing
- Two other women in her cell identified themselves as Marine Corps veterans, also detained as observers
- One veteran, bruised at wrist and ankle from agent aggression, noted it was "ironic and shocking" that her first time having a gun pointed at her was by the government she swore an oath to serve

### Sigüenza's Account
- Offered money/legal protection for names of organizers — declined
- Witnessed detainees with untreated injuries, including a man with a ripped shirt and another with a large cut on his forehead from being tackled

### Upon Release
- Released after 8 hours without charges
- Directed toward protest area upon release; tear gas deployed nearby and struck by paintball round

## Key Quotes

### From O'Keefe's USA Today Opinion Piece

On the agents' demeanor during transport:
> "One agent took a photo of me and showed it to the others, laughing. Another called me ugly. His colleague, apparently referring to Renee Good, said, 'You guys gotta stop obstructing us — that's why that lesbian bitch is dead.' In the presence of these masked men with weapons strapped to their bodies — men who claim to be safeguarding our cities — I felt only terrorized and vulnerable."

On conditions inside the Whipple Building:
> "The despondent faces and the screaming, wailing and pleading from these men, women and children — reportedly as young as 5 years old — will forever haunt me. But perhaps more haunting still was the sound of agents nearby laughing. Are our lives all just a joke to them?"

On a fellow detainee (Marine Corps veteran):
> "One of those veterans — scraped up and bruised at both wrist and ankle from the ICE agents' aggression — talked about how ironic and shocking it was that the first time she had a gun pointed at her it was by the very government she swore an oath to serve."
