---
date: 2026-01-11
time: evening
location: Pilllar Forum, 2300 Central Ave NE
city: Minneapolis
type: observers
status: resolved
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-14T08:01:12
last_updated: 2026-02-09T21:12:05
search_tags: us-citizen, observer-intimidated, chemical-agents, excessive-force, src:star-tribune, src:bring-me-the-news
---

# Musicians and Fans Pepper Sprayed Outside NE Minneapolis Venue

## Summary
Musicians and concert attendees were pepper-sprayed and hit with batons by ICE agents outside Pilllar Forum, an all-ages rock venue in Northeast Minneapolis. The incident forced cancellation of that night's show, with proceeds intended to benefit families affected by ICE detainments.

## Sources
1. Star Tribune (Jan 12, 2026): [Music fans say ICE agents pepper-sprayed them outside all-ages Minneapolis rock venue](https://www.startribune.com/fans-scuffle-ice-agents-minneapolis-all-ages-venue-pilllar-forum-northeast-central-pepper-spray/601562747)
2. Bring Me The News (Jan 12, 2026): [Concert canceled after attendees confront ICE agents](https://bringmethenews.com/minnesota-lifestyle/concert-canceled-after-attendees-confront-ice-agents)

## Affected Individual(s)
- **Names:** Multiple unnamed musicians and concert-goers
- **Citizenship:** U.S. Citizens
- **Details:** Several customers and musicians were pepper-sprayed, at least two hit with batons.

## Timeline
- **Evening** - Concert scheduled at Pilllar Forum with headliner Anita Velveeta.
- **During event** - ICE agents conducting operations on Central Ave NE.
- **Confrontation** - Agents pepper-spray musicians and attendees outside venue.
- **Aftermath** - Show cancelled; owner offers refunds (none requested).

## Witness Accounts

### Corey Bracken (Venue Owner)
Said several of his customers and musicians were pepper-sprayed by ICE agents and at least two were hit with batons on the street outside the venue, where other ICE detainments and community protests have happened in recent days.

## Official Response

### Minneapolis City Council President Elliott Payne
Joined venue owner in social media video denouncing the incident, urging residents to "Stay safe and stay vigilant."

### State Senator Doron Clark
Called Pilllar Forum "an institution here on Central."

## Aftermath
Bracken offered refunds to paid attendees of the canceled show. Proceeds were to be donated to families affected by ICE detainments, per headliner Anita Velveeta's request. "So far, I haven't heard from anyone who wants their money back," Bracken said.
