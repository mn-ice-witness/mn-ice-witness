---
date: 2026-01-14
time: morning
location: Northport Elementary School bus stop
city: Crystal
type: schools-hospitals
status: under-investigation
affected_individual_citizenship: unknown
injuries: none
created: 2026-01-15T09:33:17
last_updated: 2026-01-15T09:33:17
search_tags: children, family-separation, src:kare11, src:kstp, src:bring-me-the-news, src:other-local, src:wcco, src:pioneer-press, src:mpr, src:star-tribune
---

# Parent Detained by ICE at School Bus Stop While Waiting with Child

## Summary
ICE agents detained the parent of a Northport Elementary School student at a school bus stop in Crystal as they waited with their child. The child witnessed the arrest before safely boarding the school bus. Multiple schools in the area switched to remote learning in response.

## Sources
1. KARE 11 (Jan 14, 2026): [Parent arrested by ICE agents while waiting for school bus with child](https://www.kare11.com/article/news/local/ice-in-minnesota/parent-arrested-ice-agents-school-bus-crystal/89-6cd97be7-50b8-481a-b19d-ff94ccc9f818)
2. Bring Me The News (Jan 14, 2026): [Robbinsdale Schools parent detained by ICE while waiting with child at bus stop](https://bringmethenews.com/minnesota-news/robbinsdale-schools-parent-detained-by-ice-while-waiting-with-child-at-bus-stop)
3. CCX Media (Jan 14, 2026): [Robbinsdale Schools: Northport Parent Detained by ICE at Bus Stop](https://ccxmedia.org/news/robbinsdale-schools-northport-parent-detained-by-ice-at-bus-stop/)
4. CBS Minnesota (Jan 14, 2026): [Minnesota families pushing back against ICE operations near schools](https://www.cbsnews.com/minnesota/news/minnesota-ice-operations-twin-cities-schools/)
5. KSTP (Jan 14, 2026): [Northport Elementary parent reportedly arrested by ICE while waiting with child for the bus](https://kstp.com/kstp-news/local-news/northport-elementary-parent-reportedly-arrested-by-ice-while-waiting-with-child-for-the-bus/)
6. Pioneer Press (Jan 14, 2026): [MN lawmaker: ICE detains parent at a bus stop in Crystal](https://www.twincities.com/2026/01/14/mn-lawmaker-ice-detains-parent-at-a-bus-stop-in-crystal/)
7. Sun Sailor (Jan 14, 2026): [Rdale confirms ICE detained a parent at Crystal bus stop](https://www.hometownsource.com/sun_sailor/free/rdale-confirms-ice-detained-a-parent-at-crystal-bus-stop/article_eb407e68-3f45-4e90-a1c1-b346059f0f8f.html)
8. MPR News (Jan 23, 2026): [How schools and students are affected by ICE enforcement](https://www.mprnews.org/story/2026/01/23/how-schools-and-students-are-affected-by-ice-enforcement)
9. Star Tribune (Jan 2026): [Attendance drops at Minnesota schools as federal immigration enforcement intensifies anxieties](https://www.startribune.com/attendance-drops-at-minnesota-schools-as-federal-immigration-enforcement-intensifies-anxieties/601560458)

## Affected Individual(s)
- **Name:** Not publicly disclosed
- **Role:** Parent of Northport Elementary student
- **Citizenship:** Unknown
- **Background:** Waiting with child at school bus stop

## Timeline
- **Morning** - Parent waiting with child at Northport Elementary bus stop in Crystal
- **During wait** - ICE agents approach and detain parent
- **After arrest** - Child safely boards school bus, arrives at school
- **Later** - School contacts family, makes support services available
- **Same day** - Robbinsdale Schools offers remote learning option

## School Response
Northport Elementary Principal Bridget Dooley stated: "We recognize this news can create fear, confusion, and anxiety for students and for adults."

The school made psychologists, social workers, and other support staff available for students and staff. The principal and support staff contacted the family and communicated with families of students who were on the bus.

## Impact on Students
Students at the bus stop and on the bus witnessed the detention. The district acknowledged children may have seen what happened and offered counseling services.

## Broader Context
Following this incident, Fridley, St. Paul, and Robbinsdale school districts joined Minneapolis in offering remote learning options. Schools had reported ICE vehicles circling buildings, with staff expressing fear that "parents were going to be yanked and there was going to be horrible disruptions to the kids."

## Official Accounts

### Local Officials
- **Robbinsdale Schools:** Confirmed incident, offered remote learning
- **State legislators:** Called for ICE to stay away from schools
