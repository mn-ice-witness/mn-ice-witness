---
date: 2026-01-14
time: unknown
location: Fort Snelling ICE Facility
city: Minneapolis
type: citizens
status: ongoing
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-14T12:18:26
last_updated: 2026-01-30T11:41:26
search_tags: us-citizen, native-american, src:abc, src:cnn, src:mpr, src:other-national, src:wcco, src:wapo
---

# Three Oglala Sioux U.S. Citizens Still Detained at Fort Snelling (REMOVED)

***This incident has been removed from the main listing. See Correction Note below.***

## Correction Note (Jan 30, 2026)

**Why this was removed:** This is a follow-up to the January 8 Little Earth detention incident. On January 16, 2026, the Oglala Sioux Tribe [stated it cannot confirm](https://www.mprnews.org/story/2026/01/16/oglala-sioux-tribe-says-it-cannot-confirm-tribal-members-were-detained-by-ice-in-minneapolis) the detained individuals are actually tribal members.

**The problem:** Without confirmed tribal membership, we cannot verify U.S. citizenship, and the core claim — that U.S. citizens are being illegally held in immigration detention — is unconfirmed.

**Note:** Source #13 in this file already documents the walkback but was not reflected in the trustworthiness rating until this correction.

---

## Summary
Four days after ICE detained four Oglala Sioux tribal members from a Minneapolis homeless encampment, three remain in custody at Fort Snelling. Tribal President Frank Star Comes Out issued a formal memorandum to DHS Secretary Kristi Noem and Interior Secretary Doug Burgum demanding immediate release, calling the detention "a treaty violation" and stating "tribal citizens are not aliens" and are "categorically outside immigration jurisdiction." DHS refused to provide information unless tribe enters immigration agreement with ICE.

## Sources
1. CNN (Jan 14, 2026): [Oglala Sioux Tribe says three tribal members arrested in Minneapolis are in ICE detention](https://www.cnn.com/2026/01/14/us/oglala-sioux-tribe-minneapolis-immigration-enforcement)
2. MPR News (Jan 13, 2026): [South Dakota Tribe Oglala Sioux demands release of Lakota men in Minneapolis detained by ICE](https://www.mprnews.org/story/2026/01/13/south-dakota-tribe-oglala-sioux-demands-release-of-lakota-men-in-minneapolis-detained-by-ice)
3. ICT News (Jan 14, 2026): [Four Oglala detainees located, three still in ICE custody](https://ictnews.org/news/north-central-bureau/four-oglala-detainees-located-three-still-in-ice-custody/)
4. Axios (Jan 13, 2026): [Oglala Sioux Tribe says ICE illegally holding tribal members from Minneapolis raids](https://www.axios.com/2026/01/13/oglala-sioux-tribe-ice-holding-tribal-members)
5. Salon (Jan 14, 2026): ["A treaty violation": Oglala Sioux president demands release of tribal members detained by ICE](https://www.salon.com/2026/01/14/a-treaty-violation-oglala-sioux-president-demands-release-of-tribal-members-detained-by-ice/)
6. Newsweek (Jan 14, 2026): [ICE Detains and Holds Four Native Americans, Tribal Leader Says](https://www.newsweek.com/ice-detains-native-americans-minnesota-minneapolis-oglala-sioux-11339071)
7. CBS Minnesota (Jan 14, 2026): [4 members of Oglala Sioux Tribe detained by ICE in Minneapolis, president says](https://www.cbsnews.com/minnesota/news/oglala-sioux-tribe-members-detained-ice-minneapolis/)
8. Washington Post (Jan 13, 2026): [Oglala Sioux Tribe says three tribal members arrested in Minneapolis are in ICE detention](https://www.washingtonpost.com/national/2026/01/13/ice-minneapolis-tribal-citizens-immigration-detention/dc60a0be-f0e4-11f0-a4dc-effc74cb25af_story.html)
9. Boston Globe (Jan 14, 2026): [Oglala Sioux Tribe says three tribal members arrested in Minneapolis are in ICE detention](https://www.bostonglobe.com/2026/01/14/nation/minneapolis-oglala-tribe-members-arrested-ice/)
10. SDPB (Jan 9, 2026): [Tribal leaders respond to reports of tribal members detained by ICE](https://www.sdpb.org/politics/2026-01-09/oglala-tribal-leaders-respond-to-reports-of-tribal-members-detained-by-ice)
11. Washington Post (Jan 15, 2026): [Native Americans are being swept up by ICE in Minneapolis, tribes say](https://www.washingtonpost.com/politics/2026/01/15/native-americans-ice-minneapolis/)
12. Wisconsin Examiner (Jan 15, 2026): [Wisconsin tribes react after ICE detains Native Americans in Twin Cities](https://wisconsinexaminer.com/2026/01/15/wisconsin-tribes-react-after-ice-detains-native-americans-in-twin-cities/)
13. MPR News (Jan 16, 2026): [Oglala Sioux Tribe says it cannot confirm tribal members were detained by ICE in Minneapolis](https://www.mprnews.org/story/2026/01/16/oglala-sioux-tribe-says-it-cannot-confirm-tribal-members-were-detained-by-ice-in-minneapolis) (Note: Tribe questions verification of membership claims)
14. Bluesky - Christopher Webb (Jan 20, 2026): ["The irony of ICE detaining and disappearing the original Americans..."](https://bsky.app/profile/cwebbonline.com/post/3mcszm7fu4s25) - Commentary with Lakota proverb (6.3K likes)

## Affected Individual(s)
- **Number:** Four detained on Jan 10; three still held as of Jan 14
- **Citizenship:** U.S. Citizens (per Indian Citizenship Act of 1924), enrolled Oglala Sioux Tribe members
- **Status:** Homeless, were sheltering under bridge near Little Earth housing complex in East Phillips neighborhood
- **Current Location:** Three at Fort Snelling ICE facility; one released
- **Names:** Only first names released by DHS; last names withheld

## Timeline
- **Jan 10 (Fri)** - Four Oglala Lakota men detained from homeless encampment under bridge near Little Earth
- **Jan 13** - Axios, MPR report on tribe's demands; tribe locates detainees
- **Jan 14 (Tue)** - President Frank Star Comes Out issues formal memorandum to DHS Sec. Noem and Interior Sec. Burgum demanding release
- **Jan 16-17 (upcoming)** - Oglala Sioux Tribe enrollment office organizing assistance at Minneapolis American Indian Center to help tribal members obtain documentation and IDs

## Official Accounts

### Tribal Statement
President Frank Star Comes Out issued formal memorandum stating:
- "Enrolled tribal members are citizens of the United States by statute and citizens of the Oglala Sioux Nation by treaty."
- "Tribal citizens are not aliens and are categorically outside immigration jurisdiction."
- "This is a treaty violation. Treaties are not optional. Sovereignty is not conditional. Our citizens are not negotiable."
- "We will not enter an agreement that would authorize, or make it easier for, ICE or Homeland Security to come onto our tribal homeland to arrest or detain our tribal members."

### Tribal Demands
1. Immediate release of all enrolled tribal citizens held by immigration.
2. Full, comprehensive information from DHS on detainees.
3. Written assurances that ICE will stop detaining Native Americans.
4. Immediate government-to-government consultation.

### DHS Response
When tribe contacted DHS requesting information about detained tribal members:
- DHS released only first names of detainees.
- DHS refused additional information unless tribe "entered into an immigration agreement with ICE."
- Tribe declined this condition.
- DHS did not respond to media requests for comment.

## Legal Context
- ICE agents can arrest U.S. citizens in some cases, but agents cannot place U.S. citizens in immigration detention after citizenship is verified.
- Citizens of tribal nations became U.S. citizens in 1924 through the Indian Citizenship Act.
- Oglala Sioux Tribe promises aggressive legal action to secure release.

## Historical Context
Scholar Nick Estes, associate professor of American Indian Studies at University of Minnesota, noted Fort Snelling's "notorious anti-Indigenous, specifically anti-Dakota, history." Fort Snelling was the first military outpost in the area and Dakota people were held prisoner there during the Dakota War of 1862.

Star Comes Out stated: "The irony is not lost on us. Lakota citizens who are reported to be held at Fort Snelling — a site forever tied to the Dakota 38+2 — underscores why treaty obligations and federal accountability matter today, not just in history."

The site was historically used as a concentration camp for Native people during the Dakota removal period.

## Related Incidents
Indigenous Americans increasingly face ICE targeting. Actress Elaine Miles (Confederated Tribes of the Umatilla Indian Reservation) reported ICE agents called her tribal ID "fake" during November 2025 detention.
