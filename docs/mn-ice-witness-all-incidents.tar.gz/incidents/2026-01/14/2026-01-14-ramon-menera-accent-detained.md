---
date: 2026-01-14
time: unknown
location: Columbia Heights
city: Columbia Heights
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: none
created: 2026-01-18T01:02:13
last_updated: 2026-02-09T21:12:05
search_tags: us-citizen, citizen-check, children, src:cnn, src:star-tribune, src:other-national
---

# U.S. Citizen Detained Because of "Accent"

## Summary
Ramon Menera, a U.S. citizen, was detained by Border Patrol agents outside his home in Columbia Heights in front of his 5-year-old daughter. The agent accused him of not being a U.S. citizen "because of your accent." Menera was eventually released but described the traumatic impact on his daughter, who asked him afterward: "Are you okay? They were going to take you? I don't want to lose you."

## Sources
1. CNN Video (Jan 17, 2026): [Border Patrol agent questions if man is US citizen 'because of your accent'](https://www.cnn.com/2026/01/17/us/video/border-patrol-detain-citizen-accent-vrtc)
2. Threads Video (Jan 15, 2026): [Video of Ramon Menera detention](https://www.threads.com/@cnn/post/DTn1FDrCmbM/)
3. TikTok Video (Jan 15, 2026): [Video coverage](https://www.tiktok.com/@cnn/video/7596362207516953911)
4. Star Tribune (Jan 2026): [Columbia Heights resident, U.S. citizen, detained for accent](https://www.startribune.com/columbia-heights-resident-us-citizen-detained-for-accent/601568069)
5. KPTV (Jan 18, 2026): [Border Patrol agent detains U.S. citizen, tells him it's because 'your accent'](https://www.kptv.com/2026/01/18/border-patrol-agent-detains-us-citizen-tells-him-its-because-your-accent/)

## Affected Individual(s)
- **Name:** Ramon Menera
- **Citizenship:** U.S. citizen
- **Family:** 5-year-old daughter witnessed the detention.

## Timeline
- **Jan 14, 2026** - Menera detained outside his home by Border Patrol agents
- **During detention** - Agent tells him he's not a citizen "because of your accent"
- **Later** - Menera released

## Witness Accounts

### Ramon Menera
In an interview with CNN, Menera described his daughter's reaction: "She was shaken when I got in the home. And she's like, 'Are you okay? They were going to take you? I don't want to lose you.'"

Menera says that ICE doesn't care if you're a citizen or not, and feels he is a target because of his strong accent and appearance.

## Official Accounts

### DHS/ICE Statement
On January 18, 2026, DHS posted a statement on X defending the detention. DHS confirmed the agent "recognized one individual's accent as being from Mexico" and claimed the citizen "at first lied about where he was born, claiming Minnesota" before changing his answer to Mexico. DHS acknowledged that records confirmed he was a naturalized U.S. citizen and he was "immediately released."

**See full DHS response:** [DHS Statement: Defends Accent-Based Detention](#2026-01-18-dhs-response-accent-detention)

## Legal Context
This incident is cited in the ACLU's class-action lawsuit filed January 15, 2026, alleging widespread racial profiling, warrantless stops, and unconstitutional arrests by federal immigration agents. The ACLU argues that arrests based solely on ethnic appearance or accent violate the Fifth Amendment's Due Process Clause and the Equal Protection Clause.
