---
date: 2026-01-14
time: unknown
location: DHS Official Statement
city: Minneapolis
type: response
status: resolved
affected_individual_citizenship: n/a
injuries: none
created: 2026-01-15T13:59:54
last_updated: 2026-01-15T13:59:54
search_tags:
---

# DHS Blames Mayor Frey's Sanctuary Policies for Criminal Release

## Summary
DHS issued a statement criticizing Minneapolis Mayor Jacob Frey's sanctuary city policies, claiming they have resulted in the release of "nearly 470 criminal illegal aliens" back onto Minnesota streets since President Trump took office. The statement centered on a vehicular homicide case as evidence for why sanctuary policies are "dangerous."

## Sources
1. DHS (Jan 14, 2026): [Mayor Frey's Sanctuary Policies Release Criminal Illegal Aliens From Jails Back onto Minneapolis Streets to Terrorize More Innocent Americans](https://www.dhs.gov/news/2026/01/14/mayor-freys-sanctuary-policies-release-criminal-illegal-aliens-jails-back)

## Official Statements

### DHS Key Claims
- Governor Walz and Mayor Frey have "refused to cooperate with ICE" since President Trump took office
- "Nearly 470" "criminal illegal aliens" allegedly released back onto streets
- Sanctuary policies are "dangerous" and enable reoffending

### DHS Assistant Secretary Tricia McLaughlin
> "Tim Walz and Jacob Frey's dangerous sanctuary policies directly RELEASE criminal illegal aliens from jails and put them back on the streets to victimize more innocent Americans."

### Featured Case
DHS centered the statement on German Llangari Inga, an Ecuadorian national charged with vehicular homicide in the death of Victoria Eileen Harwell in August 2024. According to DHS:
- Arrested August 4, 2024 with blood alcohol "more than twice the legal limit"
- ICE placed a detainer
- Hennepin County Jail "refused to honor the detainer"
- Released August 6, 2024 "without notification to ICE"
- Re-arrested May 2025, again released May 13 "without notification to ICE"
- ICE apprehended him May 16, 2025

### Mayor Frey's Response
In a Fox News interview, Mayor Frey stated:
> "If you commit a crime...you should be investigated, charged, prosecuted, held accountable, and yes, arrested and put in jail."

## Context

### Legal Background on ICE Detainers
ICE detainers are administrative requests — not judicial warrants — asking local law enforcement to hold individuals beyond their scheduled release. Many jurisdictions limit cooperation because:
- Federal courts have ruled that honoring detainers without judicial warrants may violate the Fourth Amendment
- Holding people beyond their release date without warrants raises due process concerns
- Community trust issues: immigrant communities may avoid reporting crimes or cooperating with police if they fear immigration consequences

### Pattern of Administration Messaging
This statement follows a consistent DHS pattern of highlighting individual criminal cases to justify broader enforcement operations. The administration has issued similar statements in response to criticism of:
- The shooting death of Renee Good by an ICE agent (Jan 7)
- Arrests at schools and churches
- Detention of U.S. citizens and legal residents
- Use of force against observers and bystanders

### Sanctuary Policy Debate
The debate over sanctuary policies centers on different interpretations:

**DHS position:** Sanctuary policies release individuals who could be transferred to ICE custody, allowing them to reoffend.

**Sanctuary city position:**
- Individuals with criminal charges are prosecuted through the criminal justice system regardless of sanctuary policies.
- Sanctuary policies address whether local jails assist with *immigration* enforcement, not criminal prosecution.
- The featured case involves an individual who was charged and prosecuted through the criminal justice system.
