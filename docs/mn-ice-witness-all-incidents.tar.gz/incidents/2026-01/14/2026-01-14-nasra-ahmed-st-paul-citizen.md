---
date: 2026-01-14
time: 11:00
location: Lower Afton Road apartment complex
city: St. Paul
type: citizens
status: resolved
affected_individual_citizenship: us-citizen
injuries: minor
created: 2026-01-16T22:28:22
last_updated: 2026-02-09T21:12:05
search_tags: us-citizen, citizen-check, excessive-force, src:pioneer-press, src:other-national, src:sahan-journal, src:wcco
---

# U.S. Citizen Born in Minnesota Detained by ICE for Two Days

## Updates
- **Jan 18** - Nasra Ahmed describes being chained "like Hannibal Lecter" during hospital transport after suffering a seizure in detention.

## Summary
Nasra Mohamed Ahmed, a 23-year-old U.S. citizen born in Hennepin County, was detained by ICE agents on January 14 in the parking lot of her St. Paul apartment complex while on her way to pick up seizure and anxiety medication. Despite telling agents she was born in Minnesota and has never been to Somalia, she was held at Sherburne County Jail without bail for more than two days before being released to her family on Friday night (January 17) without charges. During detention, she suffered a stress-induced seizure and was taken to the hospital in full restraints. She later described being chained "like Hannibal Lecter" with a padlock. She has no criminal history.

## Sources
1. Facebook Post (Jan 15, 2026): [Community member account](https://www.facebook.com/story.php?story_fbid=25714350694874522&id=100001788329163)
2. Facebook Post (Jan 15, 2026): [Personal account](https://www.facebook.com/100078874290085/posts/869036045735531/)
3. Facebook Post (Jan 15, 2026): [Community member calling for legal action](https://www.facebook.com/story.php?story_fbid=25740710055571919&id=100001788329163)
4. X Video (Jan 15, 2026): [Video interview with Nasra Ahmed](https://x.com/FurkanGozukara/status/2013229204947554494)
5. Twin Cities Pioneer Press (Jan 16, 2026): [Family of U.S. citizen detained by ICE in St. Paul seeks her release](https://www.twincities.com/2026/01/16/family-of-u-s-citizen-detained-by-ice-in-st-paul-seeks-her-release/)
6. Twin Cities Pioneer Press (Jan 17, 2026): [St. Paul woman, U.S. citizen, released from ICE detention after two days](https://www.twincities.com/2026/01/17/st-paul-woman-u-s-citizen-released-from-ice-detention-after-two-days/)
7. Twin Cities Pioneer Press (Jan 18, 2026): [St. Paul woman, a U.S. citizen, recounts her two days in detention](https://www.twincities.com/2026/01/18/st-paul-woman-a-u-s-citizen-recounts-her-two-days-in-detention/)
8. The Mirror US (Jan 18, 2026): [US citizen scarred and bruised after she was shoved to the ground and detained by ICE for 2 days](https://www.themirror.com/news/us-news/citizen-scarred-bruised-detained-ice-1626179)
9. Complex (Jan 18, 2026): [Woman Injured, Detained, and Released by ICE Despite Being U.S. Citizen](https://www.complex.com/life/a/backwoodsaltar/us-citizen-st-paul-woman-nasra-ahmed-detained-by-ice)
10. Inquisitr (Jan 18, 2026): [ICE Agents Pulled 23-Year-Old in a Surprise Raid, Then Left Her Scarred and Bruised](https://www.inquisitr.com/ice-agents-pulled-23-year-old-in-a-surprise-raid-then-left-her-scarred-and-bruised-they-had-a-padlock-on-me)
11. Sahan Journal (Jan 21, 2026): [ICE citizen detained: St. Paul woman](https://sahanjournal.com/immigration/ice-citizen-detained-st-paul-woman/)
12. CBS Minnesota (Jan 21, 2026): [Woman, American citizen, describes being held by ICE for two days](https://www.cbsnews.com/minnesota/news/woman-american-citizen-describes-being-held-by-ice-for-two-days/)

## Affected Individual(s)
- **Name:** Nasra Mohamed Ahmed
- **Age:** 23
- **Height/Weight:** 5'4", 112 lbs
- **Birthplace:** Hennepin County, Minnesota
- **Citizenship:** U.S. Citizen (birth citizen)
- **Residence:** St. Paul (raised there)
- **Criminal History:** None - Minnesota court records show no prior criminal history
- **Medical Conditions:** Suffers from seizures and anxiety, requires prescription medication

## Timeline
- **~11:00 AM** - ICE agents detain Nasra Ahmed in parking lot of her apartment complex on Lower Afton Road in St. Paul while she was on her way to pick up a prescription
- **During detention** - Ahmed tells agents: "I'm a U.S. citizen, born in Hennepin County"
- **Wednesday-Friday** - Ahmed held at Sherburne County Jail without bail
- **Friday AM** - Jail roster lists only "federal title," "federal court" and "f" for felony; U.S. Marshals say they have no record of her

## Witness Accounts

**State Rep. Samakab Hussein:**
Ahmed told ICE agents she was a U.S. citizen born in Hennepin County. "She's never seen Somalia," Hussein noted.

Two women from neighboring apartments witnessed the detention and attempted to plead with ICE agents on Ahmed's behalf. Cell phone video was recorded of the incident.

## Family Statements

**Mohamed Ahmed (father):**
> "If a person committed a crime, they should be prosecuted, but I don't think a good person should be held in jail for so many days. She's never been arrested. She's a good citizen."

The father expressed concern about his daughter's "physical and mental health" given her medical conditions requiring prescription medication.

## Official Accounts

### ICE/DHS Response
No specific statement has been issued regarding this detention.

### Jail Records
The Sherburne County Jail roster on Friday morning listed no specific information about possible charges beyond "federal title," "federal court" and "f" for felony. The U.S. Marshals said Friday they had no record of Ahmed.

## Nasra Ahmed's Account (Jan 18 Interview)
After her release, Ahmed described her treatment in detention:

> "The way they treated me during that episode while I was transported, I was cuffed from my hands to my legs. I was covered in chains. They had a padlock on me. … While I was in the hospital, if I needed to go to the restroom or I needed to get up, they had chains on me like Hannibal Lecter, pretty much."

She also described the initial encounter: agents allegedly called her a racial slur and told her they were "making America great again."

In videos recorded by neighbors, a dozen masked agents can be seen surrounding her, forcing her to the ground and then into a car.

## Medical Treatment
During detention, Ahmed suffered a concussion and a stress-induced seizure. She was transported to the hospital in arm and leg restraints, where she received an MRI and stayed overnight. According to her press conference as reported by Sahan Journal, she also suffered a concussion from the initial encounter, and agents called her a racial slur as they handcuffed her.

## Release and Aftermath
Nasra Ahmed was released to her family around 7:45 p.m. Friday (January 17, 2026) without charges after more than two days in detention.

**State Rep. Samakab Hussein on her release:**
> "Sherburne County sent her back to Fort Snelling, and Fort Snelling released her yesterday after we talked to her attorney, (a federal public defender)."

**State Rep. Samakab Hussein on her condition after release:**
> "She went home traumatized, not eating, not talking, pissed off. She feels that she got kidnapped. The law is not protecting her. She was humiliated."
